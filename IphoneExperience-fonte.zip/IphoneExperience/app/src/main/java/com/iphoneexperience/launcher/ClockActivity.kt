package com.iphoneexperience.launcher

import android.app.Activity
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Color
import android.graphics.Typeface
import android.os.BatteryManager
import android.os.Bundle
import android.provider.MediaStore
import android.util.TypedValue
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowInsets
import android.view.WindowInsetsController
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.TextClock
import android.widget.TextView
import android.widget.Toast

/**
 * Ecrã de relógio COMPLEMENTAR (inspirado no ecrã de bloqueio do iOS).
 * NÃO substitui nem contorna o ecrã de bloqueio seguro do Android: não bloqueia o telemóvel
 * e não protege nada. Lanterna e câmara são reais.
 */
class ClockActivity : Activity() {
    private var startY = 0f
    private lateinit var torchBtn: FrameLayout
    private val torchListener: (Boolean) -> Unit = { styleTorch(it) }

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        Torch.init(this)
        window.setDecorFitsSystemWindows(false)
        window.statusBarColor = Color.TRANSPARENT
        window.navigationBarColor = Color.TRANSPARENT
        window.insetsController?.let {
            it.hide(WindowInsets.Type.statusBars() or WindowInsets.Type.navigationBars())
            it.systemBarsBehavior = WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        }
        val b = windowManager.currentWindowMetrics.bounds
        val w = b.width()
        val h = b.height()

        val root = FrameLayout(this)
        root.background = Wallpaper.make(this, true)

        val tint = 0xE6D2F4FF.toInt()
        val date = TextClock(this)
        date.format24Hour = "EEEE, d 'de' MMMM"
        date.format12Hour = "EEEE, d 'de' MMMM"
        date.setTextColor(0xCCEAF8FF.toInt())
        date.setTextSize(TypedValue.COMPLEX_UNIT_SP, 21f)
        date.typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        date.gravity = Gravity.CENTER
        root.addView(date, FrameLayout.LayoutParams(MATCH, WRAP, Gravity.TOP).apply { topMargin = (h * 0.145f).toInt() })

        val time = TextClock(this)
        time.format24Hour = "HH:mm"
        time.format12Hour = "h:mm"
        time.setTextColor(tint)
        time.setTextSize(TypedValue.COMPLEX_UNIT_PX, w * 0.265f)
        time.typeface = Typeface.create("sans-serif", Typeface.BOLD)
        time.includeFontPadding = false
        time.gravity = Gravity.CENTER
        root.addView(time, FrameLayout.LayoutParams(MATCH, WRAP, Gravity.TOP).apply { topMargin = (h * 0.145f).toInt() + dpi(26) })

        val battery = TextView(this)
        battery.setTextColor(Color.WHITE)
        battery.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
        val bi = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val lvl = bi?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val sc = bi?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
        if (lvl >= 0) battery.text = (lvl * 100 / sc).toString() + "%"
        root.addView(battery, FrameLayout.LayoutParams(WRAP, WRAP, Gravity.TOP or Gravity.END).apply { topMargin = dpi(36); marginEnd = dpi(24) })

        val d = dpi(54)
        torchBtn = FrameLayout(this)
        val ti = ImageView(this); ti.setImageResource(R.drawable.ic_flashlight); ti.setColorFilter(Color.WHITE)
        torchBtn.addView(ti, FrameLayout.LayoutParams(dpi(24), dpi(24), Gravity.CENTER))
        torchBtn.setOnClickListener { if (!Torch.toggle(this)) Toast.makeText(this, "Lanterna indisponível", Toast.LENGTH_SHORT).show() }
        root.addView(torchBtn, FrameLayout.LayoutParams(d, d, Gravity.BOTTOM or Gravity.START).apply { leftMargin = dpi(48); bottomMargin = dpi(64) })
        styleTorch(Torch.on)

        val cam = FrameLayout(this)
        cam.background = oval(0x59000000)
        val ci = ImageView(this); ci.setImageResource(R.drawable.ic_camera); ci.setColorFilter(Color.WHITE)
        cam.addView(ci, FrameLayout.LayoutParams(dpi(24), dpi(24), Gravity.CENTER))
        cam.setOnClickListener {
            try { startActivity(Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA)) }
            catch (e: Exception) { Toast.makeText(this, "Câmara indisponível", Toast.LENGTH_SHORT).show() }
        }
        root.addView(cam, FrameLayout.LayoutParams(d, d, Gravity.BOTTOM or Gravity.END).apply { rightMargin = dpi(48); bottomMargin = dpi(64) })

        val bar = View(this)
        bar.background = rounded(Color.WHITE, dp(3f))
        root.addView(bar, FrameLayout.LayoutParams(dpi(134), dpi(5), Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL).apply { bottomMargin = dpi(14) })

        val note = TextView(this)
        note.text = "Ecrã de relógio complementar — não bloqueia o telemóvel. Desliza para cima para fechar."
        note.setTextColor(0x99FFFFFF.toInt())
        note.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f)
        note.gravity = Gravity.CENTER
        root.addView(note, FrameLayout.LayoutParams(MATCH, WRAP, Gravity.BOTTOM).apply { bottomMargin = dpi(30); leftMargin = dpi(32); rightMargin = dpi(32) })

        setContentView(root)
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
    }

    private fun styleTorch(on: Boolean) {
        torchBtn.background = oval(if (on) Color.WHITE else 0x59000000)
        (torchBtn.getChildAt(0) as ImageView).setColorFilter(if (on) Color.BLACK else Color.WHITE)
    }

    override fun onStart() { super.onStart(); Torch.listeners.add(torchListener); styleTorch(Torch.on) }
    override fun onStop() { Torch.listeners.remove(torchListener); super.onStop() }

    override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
        when (ev.actionMasked) {
            MotionEvent.ACTION_DOWN -> startY = ev.rawY
            MotionEvent.ACTION_UP -> if (startY - ev.rawY > dpi(120)) { finish(); overridePendingTransition(0, android.R.anim.fade_out); return true }
        }
        return super.dispatchTouchEvent(ev)
    }
}
