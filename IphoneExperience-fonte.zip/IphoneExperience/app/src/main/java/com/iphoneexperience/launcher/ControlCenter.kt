package com.iphoneexperience.launcher

import android.app.NotificationManager
import android.app.AlertDialog
import android.bluetooth.BluetoothAdapter
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.media.AudioManager
import android.net.Uri
import android.net.wifi.WifiManager
import android.os.BatteryManager
import android.provider.AlarmClock
import android.provider.MediaStore
import android.provider.Settings
import android.util.TypedValue
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast

/** Slider vertical com cantos arredondados (brilho / volume). */
class VerticalSlider(c: Context, private val iconRes: Int, private val trackColor: Int) : View(c) {
    var value = 0.5f
        set(v) { field = v.coerceIn(0f, 1f); invalidate() }
    var onChange: ((Float) -> Unit)? = null
    var onTouchState: ((Boolean) -> Unit)? = null
    var onFirstTouch: (() -> Boolean)? = null   // devolve false para cancelar (ex.: falta de permissão)
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val icon = c.getDrawable(iconRes)!!.mutate()
    private var allowed = true

    override fun onDraw(cv: Canvas) {
        val w = width.toFloat(); val h = height.toFloat()
        val r = w * 0.32f
        val clip = Path().apply { addRoundRect(RectF(0f, 0f, w, h), r, r, Path.Direction.CW) }
        cv.save(); cv.clipPath(clip)
        p.color = trackColor
        cv.drawRect(0f, 0f, w, h, p)
        p.color = Color.WHITE
        cv.drawRect(0f, h * (1f - value), w, h, p)
        cv.restore()
        val s = (w * 0.34f).toInt()
        val cx = (w / 2).toInt(); val cy = (h - w * 0.45f).toInt()
        icon.setTint(0xFF8E8E93.toInt())
        icon.setBounds(cx - s / 2, cy - s / 2, cx + s / 2, cy + s / 2)
        icon.draw(cv)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                allowed = onFirstTouch?.invoke() ?: true
                if (!allowed) return true
                parent.requestDisallowInterceptTouchEvent(true)
                onTouchState?.invoke(true)
                set(e)
            }
            MotionEvent.ACTION_MOVE -> if (allowed) set(e)
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> onTouchState?.invoke(false)
        }
        return true
    }

    private fun set(e: MotionEvent) {
        value = 1f - (e.y / height.toFloat())
        onChange?.invoke(value)
    }
}

/** Centro de Controlo: blocos de vidro, botões circulares, sliders e cartão multimédia. */
class ControlCenter(private val a: HomeActivity) : FrameLayout(a), MediaHub.Listener {
    private val prefs = Prefs.get(a)
    private val audio: AudioManager = a.getSystemService(AudioManager::class.java)
    private val nm: NotificationManager = a.getSystemService(NotificationManager::class.java)
    private val tile = glassDark(prefs)
    private val activeBlue = 0xFF0A84FF.toInt()
    private val s: Int          // lado de uma célula
    private val gap: Int
    private val marginX: Int
    private var top = 0
    private var sliderBusy = false
    private var startY = 0f

    private lateinit var btnAir: FrameLayout
    private lateinit var btnWifi: FrameLayout
    private lateinit var btnBt: FrameLayout
    private lateinit var btnCell: FrameLayout
    private lateinit var btnRot: FrameLayout
    private lateinit var btnMute: FrameLayout
    private lateinit var btnFocus: FrameLayout
    private lateinit var btnTorch: FrameLayout
    private lateinit var sBright: VerticalSlider
    private lateinit var sVol: VerticalSlider
    private lateinit var mCover: ImageView
    private lateinit var mTitle: TextView
    private lateinit var mArtist: TextView
    private lateinit var mPlay: ImageView
    private lateinit var battery: TextView

    private val torchListener: (Boolean) -> Unit = { styleCircle(btnTorch, it, Color.WHITE, Color.BLACK) }

    init {
        setBackgroundColor(Color.argb(90, 0, 0, 0))
        setOnClickListener { a.closeControlCenter() }
        marginX = (a.sw * 0.107f).toInt()
        gap = (a.sw * 0.0365f).toInt()
        s = (a.sw - 2 * marginX - 3 * gap) / 4
        top = a.insetTop + a.dpi(70)
        build()
        refresh()
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        MediaHub.listeners.add(this)
        Torch.listeners.add(torchListener)
        refresh()
    }

    override fun onDetachedFromWindow() {
        MediaHub.listeners.remove(this)
        Torch.listeners.remove(torchListener)
        super.onDetachedFromWindow()
    }

    override fun onMediaChanged() { updateMedia() }

    // ---------------------------------------------------------------- helpers

    private fun px(col: Int) = marginX + col * (s + gap)
    private fun py(row: Int) = top + row * (s + gap)

    private fun place(v: View, col: Int, row: Int, cw: Int, rh: Int) {
        val w = cw * s + (cw - 1) * gap
        val h = rh * s + (rh - 1) * gap
        addView(v, FrameLayout.LayoutParams(w, h).apply { leftMargin = px(col); topMargin = py(row) })
    }

    private fun circle(res: Int, size: Int = s, onClick: () -> Unit): FrameLayout {
        val f = FrameLayout(a)
        f.background = oval(tile)
        val iv = ImageView(a)
        iv.setImageResource(res)
        iv.setColorFilter(Color.WHITE)
        f.addView(iv, FrameLayout.LayoutParams((size * 0.46f).toInt(), (size * 0.46f).toInt(), Gravity.CENTER))
        f.setOnClickListener { onClick() }
        f.pressScale(prefs.animations)
        return f
    }

    private fun styleCircle(f: FrameLayout, on: Boolean, onBg: Int, onIcon: Int) {
        f.background = oval(if (on) onBg else tile)
        (f.getChildAt(0) as ImageView).setColorFilter(if (on) onIcon else Color.WHITE)
    }

    private fun startSafe(i: Intent) {
        try { a.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); a.closeControlCenter() }
        catch (e: ActivityNotFoundException) { Toast.makeText(a, "Não disponível neste telemóvel", Toast.LENGTH_SHORT).show() }
    }

    private fun needWriteSettings(): Boolean {
        if (Settings.System.canWrite(a)) return false
        Toast.makeText(a, "Permite \"Alterar definições do sistema\" ao launcher", Toast.LENGTH_LONG).show()
        startSafe(Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:" + a.packageName)))
        return true
    }

    // ---------------------------------------------------------------- construção

    private fun build() {
        val round = s * 0.30f

        // cabeçalho: bateria (real) + botão para o ecrã de relógio
        battery = TextView(a)
        battery.setTextColor(Color.WHITE)
        battery.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15f)
        battery.typeface = android.graphics.Typeface.create("sans-serif-medium", android.graphics.Typeface.NORMAL)
        addView(battery, FrameLayout.LayoutParams(WRAP, WRAP).apply { leftMargin = px(0); topMargin = top - a.dpi(44) })
        val power = ImageView(a)
        power.setImageResource(R.drawable.ic_power)
        power.setColorFilter(Color.WHITE)
        power.setOnClickListener { a.startActivity(Intent(a, ClockActivity::class.java)); a.closeControlCenter() }
        addView(power, FrameLayout.LayoutParams(a.dpi(26), a.dpi(26)).apply { leftMargin = a.sw - marginX - a.dpi(26); topMargin = top - a.dpi(46) })

        // bloco de conectividade (2x2)
        val conn = FrameLayout(a)
        conn.background = rounded(tile, round * 1.2f)
        place(conn, 0, 0, 2, 2)
        val cs = (s * 0.86f).toInt()
        val pad = ((s * 2 + gap) - 2 * cs) / 3
        fun cpos(v: FrameLayout, c: Int, r: Int) {
            conn.addView(v, FrameLayout.LayoutParams(cs, cs).apply { leftMargin = pad + c * (cs + pad); topMargin = pad + r * (cs + pad) })
        }
        btnAir = circle(R.drawable.ic_airplane, cs) { startSafe(Intent(Settings.ACTION_AIRPLANE_MODE_SETTINGS)) }
        btnCell = circle(R.drawable.ic_signal, cs) { startSafe(Intent(Settings.ACTION_WIRELESS_SETTINGS)) }
        btnWifi = circle(R.drawable.ic_wifi, cs) { startSafe(Intent(Settings.Panel.ACTION_INTERNET_CONNECTIVITY)) }
        btnBt = circle(R.drawable.ic_bluetooth, cs) { startSafe(Intent(Settings.ACTION_BLUETOOTH_SETTINGS)) }
        cpos(btnAir, 0, 0); cpos(btnCell, 1, 0); cpos(btnWifi, 0, 1); cpos(btnBt, 1, 1)

        // cartão multimédia (2x2)
        val media = FrameLayout(a)
        media.background = rounded(tile, round * 1.2f)
        place(media, 2, 0, 2, 2)
        val cov = (s * 0.78f).toInt()
        mCover = ImageView(a)
        mCover.scaleType = ImageView.ScaleType.CENTER_CROP
        mCover.background = rounded(0x33FFFFFF, a.dp(14f))
        mCover.clipToOutline = true
        mCover.outlineProvider = object : android.view.ViewOutlineProvider() {
            override fun getOutline(v: View, o: android.graphics.Outline) { o.setRoundRect(0, 0, v.width, v.height, a.dp(14f)) }
        }
        media.addView(mCover, FrameLayout.LayoutParams(cov, cov).apply { leftMargin = a.dpi(14); topMargin = a.dpi(14) })
        mTitle = TextView(a)
        mTitle.setTextColor(Color.WHITE); mTitle.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
        mTitle.maxLines = 1; mTitle.ellipsize = android.text.TextUtils.TruncateAt.END
        mArtist = TextView(a)
        mArtist.setTextColor(0xB3FFFFFF.toInt()); mArtist.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
        mArtist.maxLines = 1; mArtist.ellipsize = android.text.TextUtils.TruncateAt.END
        val mw = s * 2 + gap - a.dpi(28)
        media.addView(mTitle, FrameLayout.LayoutParams(mw, WRAP).apply { leftMargin = a.dpi(14); topMargin = a.dpi(14) + cov + a.dpi(6) })
        media.addView(mArtist, FrameLayout.LayoutParams(mw, WRAP).apply { leftMargin = a.dpi(14); topMargin = a.dpi(14) + cov + a.dpi(26) })
        val mh = s * 2 + gap
        val bs = a.dpi(30)
        fun mbtn(res: Int, cx: Int, click: () -> Unit): ImageView {
            val v = ImageView(a); v.setImageResource(res); v.setColorFilter(Color.WHITE)
            v.setOnClickListener { click() }
            media.addView(v, FrameLayout.LayoutParams(bs, bs).apply { leftMargin = cx - bs / 2; topMargin = mh - a.dpi(16) - bs })
            return v
        }
        val mwTot = s * 2 + gap
        mbtn(R.drawable.ic_prev, mwTot / 2 - a.dpi(48)) { MediaHub.previous() }
        mPlay = mbtn(R.drawable.ic_play, mwTot / 2) { MediaHub.playPause() }
        mbtn(R.drawable.ic_next, mwTot / 2 + a.dpi(48)) { MediaHub.next() }
        media.setOnClickListener {
            if (!MediaHub.hasSession()) startSafe(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)) else MediaHub.openApp()
        }

        // rotação + silêncio (círculos)
        btnRot = circle(R.drawable.ic_rotate_lock) {
            if (!needWriteSettings()) {
                val cur = Settings.System.getInt(a.contentResolver, Settings.System.ACCELEROMETER_ROTATION, 1)
                Settings.System.putInt(a.contentResolver, Settings.System.ACCELEROMETER_ROTATION, if (cur == 1) 0 else 1)
                refresh()
            }
        }
        place(btnRot, 0, 2, 1, 1)
        btnMute = circle(R.drawable.ic_bell_off) {
            try {
                audio.ringerMode = if (audio.ringerMode == AudioManager.RINGER_MODE_NORMAL) AudioManager.RINGER_MODE_VIBRATE else AudioManager.RINGER_MODE_NORMAL
            } catch (e: SecurityException) {
                startSafe(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS))
            }
            refresh()
        }
        place(btnMute, 1, 2, 1, 1)

        // Foco (Não incomodar)
        btnFocus = FrameLayout(a)
        btnFocus.background = rounded(tile, s * 0.5f)
        val moon = FrameLayout(a)
        moon.background = oval(0xFFE86A33.toInt())
        val mi = ImageView(a); mi.setImageResource(R.drawable.ic_moon); mi.setColorFilter(Color.WHITE)
        moon.addView(mi, FrameLayout.LayoutParams((s * 0.40f).toInt(), (s * 0.40f).toInt(), Gravity.CENTER))
        btnFocus.addView(moon, FrameLayout.LayoutParams((s * 0.66f).toInt(), (s * 0.66f).toInt()).apply { gravity = Gravity.CENTER_VERTICAL; marginStart = (s * 0.17f).toInt() })
        val ft = TextView(a); ft.text = "Não incomodar"; ft.setTextColor(Color.WHITE); ft.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15f)
        ft.typeface = android.graphics.Typeface.create("sans-serif-medium", android.graphics.Typeface.NORMAL)
        btnFocus.addView(ft, FrameLayout.LayoutParams(WRAP, WRAP).apply { gravity = Gravity.CENTER_VERTICAL; marginStart = (s * 1.0f).toInt() })
        btnFocus.setOnClickListener { toggleDnd() }
        place(btnFocus, 0, 3, 2, 1)

        // sliders verticais (2 linhas de altura)
        sBright = VerticalSlider(a, R.drawable.ic_sun, 0x55222222)
        sBright.onFirstTouch = { !needWriteSettings() }
        sBright.onChange = { v ->
            try {
                Settings.System.putInt(a.contentResolver, Settings.System.SCREEN_BRIGHTNESS_MODE, Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL)
                Settings.System.putInt(a.contentResolver, Settings.System.SCREEN_BRIGHTNESS, (v * 255).toInt().coerceIn(1, 255))
            } catch (e: Exception) { }
        }
        sBright.onTouchState = { sliderBusy = it }
        place(sBright, 2, 2, 1, 2)
        sVol = VerticalSlider(a, R.drawable.ic_speaker, 0x55222222)
        sVol.onChange = { v ->
            val max = audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
            audio.setStreamVolume(AudioManager.STREAM_MUSIC, Math.round(v * max), 0)
        }
        sVol.onTouchState = { sliderBusy = it }
        place(sVol, 3, 2, 1, 2)

        // botões de atalhos
        fun sc(res: Int, f: () -> Unit) = Pair(res, f)
        val grid = listOf(
            sc(R.drawable.ic_calculator) {
                try { a.startActivity(Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, Intent.CATEGORY_APP_CALCULATOR).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); a.closeControlCenter() }
                catch (e: Exception) { Toast.makeText(a, "Calculadora não encontrada", Toast.LENGTH_SHORT).show() }
            },
            sc(R.drawable.ic_flashlight) { if (!Torch.toggle(a)) Toast.makeText(a, "Lanterna indisponível", Toast.LENGTH_SHORT).show() },
            sc(R.drawable.ic_camera) { startSafe(Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA)) },
            sc(R.drawable.ic_timer) { startSafe(Intent(AlarmClock.ACTION_SHOW_TIMERS)) },
            sc(R.drawable.ic_alarm) { startSafe(Intent(AlarmClock.ACTION_SHOW_ALARMS)) },
            sc(R.drawable.ic_gear) { startSafe(Intent(Settings.ACTION_SETTINGS)) },
            sc(R.drawable.ic_lock) { a.startActivity(Intent(a, ClockActivity::class.java)); a.closeControlCenter() }
        )
        for ((i, g) in grid.withIndex()) {
            val b = circle(g.first, s, g.second)
            if (g.first == R.drawable.ic_flashlight) btnTorch = b
            place(b, i % 4, 4 + i / 4, 1, 1)
        }
    }

    // ---------------------------------------------------------------- estado

    private fun toggleDnd() {
        if (!nm.isNotificationPolicyAccessGranted) {
            Toast.makeText(a, "Permite o acesso a \"Não incomodar\" ao launcher", Toast.LENGTH_LONG).show()
            startSafe(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS))
            return
        }
        val on = nm.currentInterruptionFilter != NotificationManager.INTERRUPTION_FILTER_ALL
        nm.setInterruptionFilter(if (on) NotificationManager.INTERRUPTION_FILTER_ALL else NotificationManager.INTERRUPTION_FILTER_PRIORITY)
        refresh()
    }

    fun refresh() {
        if (!::btnAir.isInitialized) return
        val air = Settings.Global.getInt(a.contentResolver, Settings.Global.AIRPLANE_MODE_ON, 0) == 1
        styleCircle(btnAir, air, 0xFFFF9F0A.toInt(), Color.WHITE)
        val wifi = try { a.applicationContext.getSystemService(WifiManager::class.java).isWifiEnabled } catch (e: Exception) { false }
        styleCircle(btnWifi, wifi, activeBlue, Color.WHITE)
        val bt = try { BluetoothAdapter.getDefaultAdapter()?.isEnabled == true } catch (e: Exception) { false }
        styleCircle(btnBt, bt, activeBlue, Color.WHITE)
        val locked = Settings.System.getInt(a.contentResolver, Settings.System.ACCELEROMETER_ROTATION, 1) == 0
        styleCircle(btnRot, locked, Color.WHITE, 0xFFFF453A.toInt())
        val quiet = audio.ringerMode != AudioManager.RINGER_MODE_NORMAL
        styleCircle(btnMute, quiet, Color.WHITE, 0xFFFF453A.toInt())
        val dnd = nm.currentInterruptionFilter != NotificationManager.INTERRUPTION_FILTER_ALL
        btnFocus.background = rounded(if (dnd) 0xCC3A3A8C.toInt() else tile, s * 0.5f)
        styleCircle(btnTorch, Torch.on, Color.WHITE, Color.BLACK)
        val max = audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
        sVol.value = audio.getStreamVolume(AudioManager.STREAM_MUSIC).toFloat() / max
        sBright.value = Settings.System.getInt(a.contentResolver, Settings.System.SCREEN_BRIGHTNESS, 128) / 255f
        val bi = a.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val lvl = bi?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val sc = bi?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
        battery.text = if (lvl >= 0) (lvl * 100 / sc).toString() + "%" else ""
        updateMedia()
    }

    private fun updateMedia() {
        if (!::mCover.isInitialized) return
        if (!MediaHub.hasSession()) {
            mCover.setImageResource(R.drawable.ic_note)
            mCover.setColorFilter(0x88FFFFFF.toInt())
            mCover.scaleType = ImageView.ScaleType.CENTER_INSIDE
            mCover.setPadding(a.dpi(14), a.dpi(14), a.dpi(14), a.dpi(14))
            mTitle.text = "Sem multimédia"
            mArtist.text = if (NotifListener.instance == null) "Toca para dar acesso" else "Nada a tocar"
            mPlay.setImageResource(R.drawable.ic_play)
            return
        }
        val art = MediaHub.art()
        mCover.clearColorFilter()
        mCover.setPadding(0, 0, 0, 0)
        mCover.scaleType = ImageView.ScaleType.CENTER_CROP
        if (art != null) mCover.setImageBitmap(art) else { mCover.setImageResource(R.drawable.ic_note); mCover.setColorFilter(0xFFFA2D48.toInt()) }
        mTitle.text = MediaHub.title() ?: ""
        mArtist.text = MediaHub.artist() ?: ""
        mPlay.setImageResource(if (MediaHub.isPlaying()) R.drawable.ic_pause else R.drawable.ic_play)
    }

    // fechar com deslize para cima (fora dos sliders)
    override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
        when (ev.actionMasked) {
            MotionEvent.ACTION_DOWN -> startY = ev.rawY
            MotionEvent.ACTION_UP -> if (!sliderBusy && startY - ev.rawY > a.dpi(90)) { a.closeControlCenter(); return true }
        }
        return super.dispatchTouchEvent(ev)
    }
}
