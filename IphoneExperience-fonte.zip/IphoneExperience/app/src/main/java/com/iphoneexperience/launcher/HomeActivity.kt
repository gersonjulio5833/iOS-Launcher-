package com.iphoneexperience.launcher

import android.app.Activity
import android.app.ActivityOptions
import android.app.AlertDialog
import android.app.SearchManager
import android.content.BroadcastReceiver
import android.content.ClipData
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Color
import android.graphics.RenderEffect
import android.graphics.Shader
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.text.InputType
import android.text.TextUtils
import android.util.TypedValue
import android.view.DragEvent
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import android.view.WindowInsets
import android.view.WindowInsetsController
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.text.Normalizer
import java.util.concurrent.Executors

class Origin(val kind: Int, val a: Int, val b: Int) {
    companion object { const val PAGE = 0; const val DOCK = 1 }
}

/** Ecrã inicial: grelha de 4 colunas, páginas, dock, pastas, pesquisa e gestos. */
class HomeActivity : Activity() {
    lateinit var prefs: Prefs
    private lateinit var root: FrameLayout
    private lateinit var content: FrameLayout
    private var pager: PagerView? = null
    private var dotsRow: LinearLayout? = null
    private var dockBar: LinearLayout? = null

    private var model = HomeModel()
    var apps: Map<String, AppInfo> = emptyMap()
    var insetTop = 0
    var insetBottom = 0
    var sw = 0
    var sh = 0
    private var cellW = 0
    private var pitch = 0
    private var iconPx = 0
    private var pagerTop = 0
    private var dockLeft = 0
    private var dockTop = 0
    private var dockW = 0
    private var dockH = 0
    private var uiKey = ""

    private var dragSrc: Origin? = null
    private var edgeDir = 0
    private val ui = Handler(Looper.getMainLooper())
    private val exec = Executors.newSingleThreadExecutor()

    private var cc: ControlCenter? = null
    private var notif: NotifPanel? = null
    private var searchView: View? = null
    private var searchField: EditText? = null
    private var folderView: View? = null

    private val pkgReceiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) { loadApps() }
    }

    // ------------------------------------------------------------------ ciclo de vida

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        prefs = Prefs.get(this)
        Torch.init(this)
        window.setDecorFitsSystemWindows(false)
        window.statusBarColor = Color.TRANSPARENT
        window.navigationBarColor = Color.TRANSPARENT
        window.isNavigationBarContrastEnforced = false

        val b = windowManager.currentWindowMetrics.bounds
        sw = b.width(); sh = b.height()

        root = FrameLayout(this)
        root.background = Wallpaper.make(this, false)
        content = FrameLayout(this)
        root.addView(content, FrameLayout.LayoutParams(MATCH, MATCH))
        setContentView(root)

        root.setOnApplyWindowInsetsListener { _, ins ->
            val bars = ins.getInsets(WindowInsets.Type.systemBars())
            if (bars.top != insetTop || bars.bottom != insetBottom || pager == null) {
                insetTop = bars.top; insetBottom = bars.bottom
                buildUi()
            }
            ins
        }
        root.setOnDragListener { _, e -> onDrag(e) }

        val f = IntentFilter().apply {
            addAction(Intent.ACTION_PACKAGE_ADDED)
            addAction(Intent.ACTION_PACKAGE_REMOVED)
            addAction(Intent.ACTION_PACKAGE_CHANGED)
            addDataScheme("package")
        }
        registerReceiver(pkgReceiver, f)
        applyBars()
        loadApps()
    }

    override fun onDestroy() {
        try { unregisterReceiver(pkgReceiver) } catch (e: Exception) { }
        super.onDestroy()
    }

    override fun onResume() {
        super.onResume()
        val key = currentUiKey()
        if (key != uiKey && pager != null) {
            root.background = Wallpaper.make(this, false)
            applyBars()
            buildUi()
        }
        cc?.refresh()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        if (intent.action == Intent.ACTION_MAIN && intent.hasCategory(Intent.CATEGORY_HOME)) {
            if (overlayOpen()) closeAllOverlays() else pager?.snapTo(0)
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (overlayOpen()) closeAllOverlays() else pager?.snapTo(0)
    }

    private fun currentUiKey() =
        "${prefs.iconScale}|${prefs.glass}|${prefs.showLabels}|${prefs.showSearch}|${prefs.theme}|${prefs.wallpaperMode}|${Wallpaper.file(this).lastModified()}"

    private fun applyBars() {
        val light = prefs.wallpaperMode == 0
        window.insetsController?.setSystemBarsAppearance(
            if (light) WindowInsetsController.APPEARANCE_LIGHT_STATUS_BARS else 0,
            WindowInsetsController.APPEARANCE_LIGHT_STATUS_BARS
        )
    }

    // ------------------------------------------------------------------ dados

    private fun loadApps() {
        exec.execute {
            val list = AppRepo.loadAll(this)
            runOnUiThread {
                apps = list.associateBy { it.id }
                model = HomeModel.load(prefs, apps, this)
                if (pager != null) renderAll()
            }
        }
    }

    fun appList(): Collection<AppInfo> = apps.values

    // ------------------------------------------------------------------ construção da UI

    private fun buildUi() {
        uiKey = currentUiKey()
        content.removeAllViews()
        cellW = sw / 4
        iconPx = (sw * 0.152f * prefs.iconScale / 100f).toInt()
        dockH = dpi(92)
        dockW = sw - dpi(24)
        dockLeft = (sw - dockW) / 2
        val dockBottom = insetBottom + dpi(8)
        dockTop = sh - dockBottom - dockH
        val pillH = dpi(34)
        val dotsH = dpi(18)
        val reserved = dockBottom + dockH + dpi(12) + (if (prefs.showSearch) pillH + dpi(8) else 0) + dotsH
        pagerTop = insetTop + dpi(10)
        val avail = sh - pagerTop - reserved
        pitch = minOf((sw * 0.255f).toInt(), avail / 6)

        val pg = PagerView(this)
        pg.onPageChanged = { updateDots() }
        pager = pg
        content.addView(pg, FrameLayout.LayoutParams(MATCH, pitch * 6).apply { topMargin = pagerTop })

        // pontos de página
        val dr = LinearLayout(this)
        dr.orientation = LinearLayout.HORIZONTAL
        dr.gravity = Gravity.CENTER
        dotsRow = dr
        val dotsBottom = dockBottom + dockH + dpi(12) + (if (prefs.showSearch) pillH + dpi(8) else 0)
        content.addView(dr, FrameLayout.LayoutParams(WRAP, dotsH).apply {
            gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL; bottomMargin = dotsBottom
        })

        // pílula de pesquisa
        if (prefs.showSearch) {
            val pill = TextView(this)
            pill.text = "  Pesquisar"
            pill.setTextColor(Color.WHITE)
            pill.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
            pill.typeface = android.graphics.Typeface.create("sans-serif-medium", android.graphics.Typeface.NORMAL)
            pill.gravity = Gravity.CENTER
            pill.setPadding(dpi(18), 0, dpi(18), 0)
            pill.background = rounded(Color.argb(80, 0, 0, 0), dp(17f))
            val ic = getDrawable(R.drawable.ic_search)!!.mutate()
            ic.setTint(Color.WHITE)
            ic.setBounds(0, 0, dpi(14), dpi(14))
            pill.setCompoundDrawables(ic, null, null, null)
            pill.setOnClickListener { showSearch() }
            pill.pressScale(prefs.animations)
            content.addView(pill, FrameLayout.LayoutParams(WRAP, pillH).apply {
                gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
                bottomMargin = dockBottom + dockH + dpi(12)
            })
        }

        // dock
        val dock = LinearLayout(this)
        dock.orientation = LinearLayout.HORIZONTAL
        dock.gravity = Gravity.CENTER
        dock.background = rounded(glassLight(prefs), dp(34f))
        dockBar = dock
        content.addView(dock, FrameLayout.LayoutParams(dockW, dockH).apply {
            gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL; bottomMargin = dockBottom
        })

        if (apps.isNotEmpty()) renderAll()
    }

    private fun renderAll() {
        val pg = pager ?: return
        val dock = dockBar ?: return
        // páginas
        val views = mutableListOf<View>()
        for ((pi, items) in model.pages.withIndex()) {
            val page = FrameLayout(this)
            for ((i, item) in items.withIndex()) {
                val o = Origin(Origin.PAGE, pi, i)
                val v: View? = when (item) {
                    is Item.App -> apps[item.id]?.let { appCell(it, o, cellW, pitch, prefs.showLabels) { v -> launch(it, v) } }
                    is Item.Folder -> folderCell(item, o, cellW, pitch)
                }
                if (v != null) page.addView(v, FrameLayout.LayoutParams(cellW, pitch).apply {
                    leftMargin = (i % 4) * cellW; topMargin = (i / 4) * pitch
                })
            }
            views.add(page)
        }
        pg.setPages(views)
        // dock
        dock.removeAllViews()
        val slotW = dockW / 4
        for ((si, id) in model.dock.withIndex()) {
            val app = apps[id] ?: continue
            dock.addView(appCell(app, Origin(Origin.DOCK, si, 0), slotW, dockH, false) { v -> launch(app, v) },
                LinearLayout.LayoutParams(slotW, dockH))
        }
        updateDots()
    }

    private fun updateDots() {
        val dr = dotsRow ?: return
        val pg = pager ?: return
        dr.removeAllViews()
        if (pg.pageCount < 2) return
        for (i in 0 until pg.pageCount) {
            val d = View(this)
            d.background = oval(if (i == pg.current) Color.WHITE else 0x66FFFFFF)
            dr.addView(d, LinearLayout.LayoutParams(dpi(7), dpi(7)).apply { marginStart = dpi(4); marginEnd = dpi(4) })
        }
    }

    private fun label(text: String, w: Int): TextView = TextView(this).apply {
        this.text = text
        setTextColor(Color.WHITE)
        setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f)
        maxLines = 1
        ellipsize = TextUtils.TruncateAt.END
        gravity = Gravity.CENTER
        setShadowLayer(dp(2f), 0f, dp(1f), 0x66000000)
        layoutParams = LinearLayout.LayoutParams(w, WRAP).apply { topMargin = dpi(5) }
    }

    private fun appCell(app: AppInfo, origin: Origin?, w: Int, h: Int, labels: Boolean, onTap: (View) -> Unit): View {
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.gravity = Gravity.CENTER_HORIZONTAL
        val top = ((h - iconPx - (if (labels) dpi(18) else 0)) / 2).coerceAtLeast(0)
        col.setPadding(0, top, 0, 0)
        val iv = ImageView(this)
        iv.tag = app.id
        col.addView(iv, LinearLayout.LayoutParams(iconPx, iconPx))
        Icons.load(this, app, iconPx) { b -> if (iv.tag == app.id) iv.setImageBitmap(b) }
        if (labels) col.addView(label(app.label, w - dpi(6)))
        col.setOnClickListener { onTap(iv) }
        col.pressScale(prefs.animations)
        if (origin != null) col.setOnLongClickListener { startDrag(col, origin) }
        return col
    }

    private fun folderCell(f: Item.Folder, origin: Origin?, w: Int, h: Int): View {
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.gravity = Gravity.CENTER_HORIZONTAL
        col.setPadding(0, ((h - iconPx - dpi(18)) / 2).coerceAtLeast(0), 0, 0)
        val iv = ImageView(this)
        iv.tag = f
        col.addView(iv, LinearLayout.LayoutParams(iconPx, iconPx))
        Icons.folder(this, f.ids.mapNotNull { apps[it] }, iconPx) { b -> if (iv.tag === f) iv.setImageBitmap(b) }
        col.addView(label(f.name, w - dpi(6)))
        col.setOnClickListener { openFolder(f) }
        col.pressScale(prefs.animations)
        if (origin != null) col.setOnLongClickListener { startDrag(col, origin) }
        return col
    }

    // ------------------------------------------------------------------ lançar apps

    fun launch(app: AppInfo, from: View?) {
        val i = Intent(Intent.ACTION_MAIN)
            .addCategory(Intent.CATEGORY_LAUNCHER)
            .setComponent(ComponentName(app.pkg, app.cls))
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
        try {
            if (from != null && prefs.animations) {
                val o = ActivityOptions.makeScaleUpAnimation(from, 0, 0, from.width, from.height)
                startActivity(i, o.toBundle())
            } else startActivity(i)
        } catch (e: Exception) {
            Toast.makeText(this, "Não foi possível abrir ${app.label}", Toast.LENGTH_SHORT).show()
        }
    }

    // ------------------------------------------------------------------ arrastar e largar

    private fun startDrag(v: View, o: Origin): Boolean {
        dragSrc = o
        v.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
        val ok = v.startDragAndDrop(ClipData.newPlainText("item", "item"), View.DragShadowBuilder(v), null, 0)
        if (ok) v.alpha = 0.25f else dragSrc = null
        return ok
    }

    private fun onDrag(e: DragEvent): Boolean {
        when (e.action) {
            DragEvent.ACTION_DRAG_STARTED -> return dragSrc != null
            DragEvent.ACTION_DRAG_LOCATION -> handleEdge(e.x)
            DragEvent.ACTION_DROP -> { cancelEdge(); handleDrop(e.x, e.y); }
            DragEvent.ACTION_DRAG_ENDED -> { cancelEdge(); dragSrc = null; renderAll() }
        }
        return true
    }

    private val edgeRunnable = object : Runnable {
        override fun run() {
            val pg = pager ?: return
            if (edgeDir == 0) return
            val target = pg.current + edgeDir
            if (target >= pg.pageCount && target >= 0 && model.pages.lastOrNull()?.isNotEmpty() == true) {
                pg.addPage(FrameLayout(this@HomeActivity))
            }
            if (target in 0 until pg.pageCount) pg.snapTo(target)
            ui.postDelayed(this, 900)
        }
    }

    private fun handleEdge(x: Float) {
        val d = if (x < dpi(28)) -1 else if (x > sw - dpi(28)) 1 else 0
        if (d != edgeDir) {
            ui.removeCallbacks(edgeRunnable)
            edgeDir = d
            if (d != 0) ui.postDelayed(edgeRunnable, 650)
        }
    }

    private fun cancelEdge() { ui.removeCallbacks(edgeRunnable); edgeDir = 0 }

    private fun itemOf(o: Origin): Item? = when (o.kind) {
        Origin.PAGE -> model.pages.getOrNull(o.a)?.getOrNull(o.b)
        else -> model.dock.getOrNull(o.a)?.let { Item.App(it) }
    }

    private fun removeSrc(o: Origin, item: Item) {
        if (o.kind == Origin.PAGE) {
            model.pages.getOrNull(o.a)?.let { l ->
                val i = l.indexOfFirst { it === item }
                if (i >= 0) l.removeAt(i)
            }
        } else if (o.a in model.dock.indices) model.dock.removeAt(o.a)
    }

    private fun handleDrop(x: Float, y: Float) {
        val o = dragSrc ?: return
        dragSrc = null
        val item = itemOf(o) ?: return
        var changed = false
        if (y >= dockTop - dpi(10)) changed = dockDrop(x, o, item)
        else if (y >= pagerTop && y <= pagerTop + pitch * 6) changed = pageDrop(x, y, o, item)
        if (changed) {
            model.normalize()
            model.save(prefs)
        }
    }

    private fun dockDrop(x: Float, o: Origin, item: Item): Boolean {
        val app = item as? Item.App
        if (app == null) { Toast.makeText(this, "As pastas não podem ir para o dock", Toast.LENGTH_SHORT).show(); return false }
        val slotW = dockW / 4f
        val n = model.dock.size
        val start = dockLeft + (dockW - n * slotW) / 2f
        val slot = ((x - start) / slotW).toInt().coerceIn(0, n)
        if (o.kind == Origin.DOCK) {
            if (slot == o.a || slot == o.a + 1) { showItemMenu(item); return false }
            val id = model.dock.removeAt(o.a)
            model.dock.add(slot.coerceIn(0, model.dock.size), id)
            return true
        }
        if (model.dock.size >= 4) {
            val t = slot.coerceIn(0, model.dock.size - 1)
            val displaced = model.dock[t]
            model.dock[t] = app.id
            val list = model.pages.getOrNull(o.a) ?: return true
            val idx = list.indexOfFirst { it === item }
            if (idx >= 0) list[idx] = Item.App(displaced)
        } else {
            removeSrc(o, item)
            model.dock.add(slot.coerceIn(0, model.dock.size), app.id)
        }
        return true
    }

    private fun pageDrop(x: Float, y: Float, o: Origin, item: Item): Boolean {
        val pg = pager ?: return false
        val pageIdx = pg.current
        while (model.pages.size <= pageIdx) model.pages.add(mutableListOf())
        val list = model.pages[pageIdx]
        val col = (x / cellW).toInt().coerceIn(0, 3)
        val row = ((y - pagerTop) / pitch).toInt().coerceIn(0, 5)
        val idx = row * 4 + col
        if (idx < list.size) {
            val target = list[idx]
            if (target === item) { showItemMenu(item); return false }
            val cx = col * cellW + cellW / 2f
            val cy = pagerTop + row * pitch + pitch / 2f
            val near = Math.abs(x - cx) < cellW * 0.30f && Math.abs(y - cy) < pitch * 0.32f
            if (near && item is Item.App) {
                if (target is Item.Folder) {
                    removeSrc(o, item)
                    target.ids.add(item.id)
                    return true
                }
                if (target is Item.App && target.id != item.id) {
                    removeSrc(o, item)
                    val ti = list.indexOfFirst { it === target }
                    if (ti >= 0) list[ti] = Item.Folder("Pasta", mutableListOf(target.id, item.id))
                    return true
                }
            }
        }
        removeSrc(o, item)
        list.add(idx.coerceIn(0, list.size), item)
        return true
    }

    // ------------------------------------------------------------------ menus e pastas

    private fun showItemMenu(item: Item) {
        when (item) {
            is Item.App -> {
                val app = apps[item.id] ?: return
                AlertDialog.Builder(this).setTitle(app.label)
                    .setItems(arrayOf("Informações da app", "Desinstalar")) { _, which ->
                        val uri = Uri.parse("package:" + app.pkg)
                        if (which == 0) startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, uri))
                        else startActivity(Intent(Intent.ACTION_DELETE, uri))
                    }.show()
            }
            is Item.Folder -> {
                AlertDialog.Builder(this).setTitle(item.name)
                    .setItems(arrayOf("Mudar nome", "Desfazer pasta")) { _, which ->
                        if (which == 0) renameFolder(item) else dissolveFolder(item)
                    }.show()
            }
        }
    }

    private fun renameFolder(f: Item.Folder) {
        val et = EditText(this)
        et.setText(f.name)
        AlertDialog.Builder(this).setTitle("Nome da pasta").setView(et)
            .setPositiveButton("OK") { _, _ ->
                f.name = et.text.toString().ifBlank { "Pasta" }
                model.save(prefs); renderAll()
            }.setNegativeButton("Cancelar", null).show()
    }

    private fun dissolveFolder(f: Item.Folder) {
        for (page in model.pages) {
            val i = page.indexOfFirst { it === f }
            if (i >= 0) {
                page.removeAt(i)
                page.addAll(i, f.ids.map { Item.App(it) })
                break
            }
        }
        model.normalize(); model.save(prefs); renderAll()
    }

    private fun openFolder(f: Item.Folder) {
        if (folderView != null) return
        val ov = FrameLayout(this)
        ov.setBackgroundColor(Color.argb(90, 0, 0, 0))
        ov.setOnClickListener { closeFolder() }

        val cardW = (sw * 0.88f).toInt()
        val card = LinearLayout(this)
        card.orientation = LinearLayout.VERTICAL
        card.setPadding(dpi(12), dpi(16), dpi(12), dpi(16))
        card.background = rounded(Color.argb(200, 70, 72, 82), dp(36f))
        card.isClickable = true

        val title = EditText(this)
        title.setText(f.name)
        title.setTextColor(Color.WHITE)
        title.setTextSize(TypedValue.COMPLEX_UNIT_SP, 20f)
        title.typeface = android.graphics.Typeface.create("sans-serif-medium", android.graphics.Typeface.NORMAL)
        title.gravity = Gravity.CENTER
        title.background = null
        title.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
        title.imeOptions = EditorInfo.IME_ACTION_DONE
        title.setSingleLine()
        title.setOnEditorActionListener { v, _, _ ->
            f.name = v.text.toString().ifBlank { "Pasta" }
            model.save(prefs)
            (getSystemService(InputMethodManager::class.java)).hideSoftInputFromWindow(v.windowToken, 0)
            true
        }
        card.addView(title, LinearLayout.LayoutParams(MATCH, WRAP).apply { bottomMargin = dpi(8) })

        val cw = (cardW - dpi(24)) / 3
        val ch = pitch
        val sv = ScrollView(this)
        val grid = LinearLayout(this)
        grid.orientation = LinearLayout.VERTICAL
        sv.addView(grid, FrameLayout.LayoutParams(MATCH, WRAP))
        for (rowIds in f.ids.chunked(3)) {
            val r = LinearLayout(this)
            r.orientation = LinearLayout.HORIZONTAL
            for (id in rowIds) {
                val app = apps[id] ?: continue
                val cell = appCell(app, null, cw, ch, true) { v -> closeFolder(); launch(app, v) }
                cell.setOnLongClickListener {
                    AlertDialog.Builder(this).setTitle(app.label)
                        .setItems(arrayOf("Tirar da pasta", "Informações da app")) { _, which ->
                            if (which == 0) {
                                f.ids.remove(id)
                                for (page in model.pages) {
                                    val i = page.indexOfFirst { it === f }
                                    if (i >= 0) { page.add(i + 1, Item.App(id)); break }
                                }
                                closeFolder()
                            } else startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + app.pkg)))
                        }.show()
                    true
                }
                r.addView(cell, LinearLayout.LayoutParams(cw, ch))
            }
            grid.addView(r)
        }
        card.addView(sv, LinearLayout.LayoutParams(MATCH, minOf(ch * 3, sh / 2)))
        ov.addView(card, FrameLayout.LayoutParams(cardW, WRAP, Gravity.CENTER))
        folderView = ov
        root.addView(ov, FrameLayout.LayoutParams(MATCH, MATCH))
        updateBlur()
        if (prefs.animations) {
            card.scaleX = 0.7f; card.scaleY = 0.7f; ov.alpha = 0f
            ov.animate().alpha(1f).setDuration(200).start()
            card.animate().scaleX(1f).scaleY(1f).setDuration(240).start()
        }
    }

    private fun closeFolder() {
        val v = folderView ?: return
        folderView = null
        root.removeView(v)
        model.normalize(); model.save(prefs)
        updateBlur()
        renderAll()
    }

    // ------------------------------------------------------------------ pesquisa

    private fun norm(s: String): String =
        Normalizer.normalize(s, Normalizer.Form.NFD).replace(Regex("\\p{M}+"), "").lowercase()

    fun showSearch() {
        if (overlayOpen()) return
        val ov = FrameLayout(this)
        ov.setBackgroundColor(Color.argb(120, 0, 0, 0))
        ov.setOnClickListener { closeSearch() }
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dpi(16), insetTop + dpi(16), dpi(16), 0)

        val field = EditText(this)
        field.hint = "Pesquisar"
        field.setHintTextColor(0x99FFFFFF.toInt())
        field.setTextColor(Color.WHITE)
        field.setTextSize(TypedValue.COMPLEX_UNIT_SP, 17f)
        field.setSingleLine()
        field.imeOptions = EditorInfo.IME_ACTION_SEARCH
        field.background = rounded(Color.argb(110, 90, 90, 96), dp(14f))
        field.setPadding(dpi(14), dpi(10), dpi(14), dpi(10))
        val ic = getDrawable(R.drawable.ic_search)!!.mutate()
        ic.setTint(0xB3FFFFFF.toInt())
        ic.setBounds(0, 0, dpi(18), dpi(18))
        field.setCompoundDrawables(ic, null, null, null)
        field.compoundDrawablePadding = dpi(8)
        col.addView(field, LinearLayout.LayoutParams(MATCH, WRAP))

        val results = LinearLayout(this)
        results.orientation = LinearLayout.VERTICAL
        val sv = ScrollView(this)
        sv.addView(results, FrameLayout.LayoutParams(MATCH, WRAP))
        col.addView(sv, LinearLayout.LayoutParams(MATCH, (sh * 0.40f).toInt()).apply { topMargin = dpi(10) })
        ov.addView(col, FrameLayout.LayoutParams(MATCH, MATCH))

        fun row(app: AppInfo): View {
            val r = LinearLayout(this)
            r.orientation = LinearLayout.HORIZONTAL
            r.gravity = Gravity.CENTER_VERTICAL
            r.setPadding(dpi(6), dpi(7), dpi(6), dpi(7))
            val iv = ImageView(this)
            iv.tag = app.id
            r.addView(iv, LinearLayout.LayoutParams(dpi(44), dpi(44)))
            Icons.load(this, app, dpi(44)) { b -> if (iv.tag == app.id) iv.setImageBitmap(b) }
            val t = TextView(this)
            t.text = app.label
            t.setTextColor(Color.WHITE)
            t.setTextSize(TypedValue.COMPLEX_UNIT_SP, 17f)
            r.addView(t, LinearLayout.LayoutParams(WRAP, WRAP).apply { marginStart = dpi(14) })
            r.setOnClickListener { closeSearch(); launch(app, iv) }
            return r
        }

        fun fill(q: String) {
            results.removeAllViews()
            val n = norm(q.trim())
            if (n.isEmpty()) return
            apps.values.filter { norm(it.label).contains(n) }.take(12).forEach { results.addView(row(it)) }
            val web = TextView(this)
            web.text = "Pesquisar na Web: " + q.trim()
            web.setTextColor(0xFF64B5FF.toInt())
            web.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16f)
            web.setPadding(dpi(6), dpi(14), dpi(6), dpi(14))
            web.setOnClickListener {
                closeSearch()
                try { startActivity(Intent(Intent.ACTION_WEB_SEARCH).putExtra(SearchManager.QUERY, q.trim()).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
                catch (e: Exception) { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=" + Uri.encode(q.trim())))) }
            }
            results.addView(web)
        }
        field.addTextChangedListener(object : android.text.TextWatcher {
            override fun afterTextChanged(s: android.text.Editable?) { fill(s?.toString() ?: "") }
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
        })
        field.setOnEditorActionListener { _, _, _ ->
            val first = apps.values.firstOrNull { norm(it.label).contains(norm(field.text.toString().trim())) && field.text.isNotBlank() }
            if (first != null) { closeSearch(); launch(first, null) }
            true
        }
        searchView = ov
        searchField = field
        root.addView(ov, FrameLayout.LayoutParams(MATCH, MATCH))
        updateBlur()
        if (prefs.animations) { ov.alpha = 0f; ov.animate().alpha(1f).setDuration(180).start() }
        field.requestFocus()
        field.postDelayed({ getSystemService(InputMethodManager::class.java).showSoftInput(field, 0) }, 150)
    }

    private fun closeSearch() {
        val v = searchView ?: return
        searchField?.let { getSystemService(InputMethodManager::class.java).hideSoftInputFromWindow(it.windowToken, 0) }
        searchView = null; searchField = null
        root.removeView(v)
        updateBlur()
    }

    // ------------------------------------------------------------------ painéis (controlo / notificações)

    fun overlayOpen(): Boolean = cc != null || notif != null || searchView != null || folderView != null

    fun closeAllOverlays() {
        closeSearch(); closeFolder(); closeControlCenter(); closeNotifications()
    }

    fun updateBlur() {
        val any = cc != null || notif != null || searchView != null || folderView != null
        content.setRenderEffect(if (any) RenderEffect.createBlurEffect(28f, 28f, Shader.TileMode.CLAMP) else null)
    }

    private fun addOverlay(v: View) {
        root.addView(v, FrameLayout.LayoutParams(MATCH, MATCH))
        updateBlur()
        if (prefs.animations) {
            v.alpha = 0f; v.scaleX = 1.06f; v.scaleY = 1.06f
            v.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(240).start()
        }
    }

    private fun removeOverlay(v: View) {
        if (prefs.animations) {
            v.animate().alpha(0f).scaleX(1.06f).scaleY(1.06f).setDuration(180)
                .withEndAction { root.removeView(v); updateBlur() }.start()
        } else { root.removeView(v); updateBlur() }
    }

    fun showControlCenter() {
        if (overlayOpen()) return
        val v = ControlCenter(this)
        cc = v
        addOverlay(v)
    }

    fun closeControlCenter() {
        val v = cc ?: return
        cc = null
        removeOverlay(v)
    }

    fun showNotifications() {
        if (overlayOpen()) return
        val v = NotifPanel(this)
        notif = v
        addOverlay(v)
    }

    fun closeNotifications() {
        val v = notif ?: return
        notif = null
        removeOverlay(v)
    }

    // ------------------------------------------------------------------ gestos

    private var gx = 0f
    private var gy = 0f
    private var gTracking = false
    private var gFired = false

    override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
        if (overlayOpen()) return super.dispatchTouchEvent(ev)
        when (ev.actionMasked) {
            MotionEvent.ACTION_DOWN -> { gx = ev.rawX; gy = ev.rawY; gTracking = true; gFired = false }
            MotionEvent.ACTION_MOVE -> if (gTracking && !gFired && dragSrc == null) {
                val dy = ev.rawY - gy
                val dx = ev.rawX - gx
                if (dy > dpi(70) && dy > Math.abs(dx) * 1.6f) {
                    gFired = true
                    gTracking = false
                    val c = MotionEvent.obtain(ev)
                    c.action = MotionEvent.ACTION_CANCEL
                    super.dispatchTouchEvent(c)
                    c.recycle()
                    when {
                        gy < sh * 0.22f && gx < sw * 0.5f -> showNotifications()
                        gy < sh * 0.22f -> showControlCenter()
                        else -> showSearch()
                    }
                    return true
                }
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> gTracking = false
        }
        if (gFired && ev.actionMasked != MotionEvent.ACTION_DOWN) return true
        return super.dispatchTouchEvent(ev)
    }
}
