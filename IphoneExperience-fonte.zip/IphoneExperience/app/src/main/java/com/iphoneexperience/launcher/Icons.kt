package com.iphoneexperience.launcher

import android.content.ComponentName
import android.content.Context
import android.graphics.*
import android.graphics.drawable.AdaptiveIconDrawable
import android.graphics.drawable.Drawable
import android.os.Handler
import android.os.Looper
import android.util.LruCache
import java.util.concurrent.Executors

/** Desenha os ícones das apps reais dentro de uma máscara arredondada (estilo iOS). */
object Icons {
    private val cache = LruCache<String, Bitmap>(256)
    private val exec = Executors.newFixedThreadPool(2)
    private val main = Handler(Looper.getMainLooper())

    fun squircle(size: Int): Path {
        val r = size * 0.225f
        return Path().apply { addRoundRect(RectF(0f, 0f, size.toFloat(), size.toFloat()), r, r, Path.Direction.CW) }
    }

    fun render(d: Drawable, size: Int): Bitmap {
        val bmp = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        if (d is AdaptiveIconDrawable) {
            val o = (size * 0.25f).toInt()
            d.background?.let { it.setBounds(-o, -o, size + o, size + o); it.draw(c) }
            d.foreground?.let { it.setBounds(-o, -o, size + o, size + o); it.draw(c) }
        } else {
            c.drawColor(Color.WHITE)
            val inset = (size * 0.14f).toInt()
            d.setBounds(inset, inset, size - inset, size - inset)
            d.draw(c)
        }
        val mask = Path(squircle(size))
        mask.fillType = Path.FillType.INVERSE_EVEN_ODD
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        p.xfermode = PorterDuffXfermode(PorterDuff.Mode.CLEAR)
        c.drawPath(mask, p)
        return bmp
    }

    private fun sync(ctx: Context, app: AppInfo, size: Int): Bitmap {
        val key = app.id + "@" + size
        cache.get(key)?.let { return it }
        val d = try {
            ctx.packageManager.getActivityIcon(ComponentName(app.pkg, app.cls))
        } catch (e: Exception) { ctx.packageManager.defaultActivityIcon }
        val b = render(d, size)
        cache.put(key, b)
        return b
    }

    fun load(ctx: Context, app: AppInfo, size: Int, cb: (Bitmap) -> Unit) {
        val app2 = ctx.applicationContext
        cache.get(app.id + "@" + size)?.let { cb(it); return }
        exec.execute {
            val b = sync(app2, app, size)
            main.post { cb(b) }
        }
    }

    /** Ícone de pasta: fundo translúcido com miniaturas 3x3 das apps. */
    fun folder(ctx: Context, apps: List<AppInfo>, size: Int, cb: (Bitmap) -> Unit) {
        val app2 = ctx.applicationContext
        exec.execute {
            val bmp = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
            val c = Canvas(bmp)
            val bg = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0x59FFFFFF }
            c.drawPath(squircle(size), bg)
            val pad = size * 0.12f
            val cell = (size - 2 * pad) / 3f
            val mini = (cell * 0.84f).toInt().coerceAtLeast(8)
            for ((i, a) in apps.take(9).withIndex()) {
                val b = sync(app2, a, mini)
                val x = pad + (i % 3) * cell + (cell - mini) / 2f
                val y = pad + (i / 3) * cell + (cell - mini) / 2f
                c.drawBitmap(b, x, y, null)
            }
            main.post { cb(bmp) }
        }
    }
}
