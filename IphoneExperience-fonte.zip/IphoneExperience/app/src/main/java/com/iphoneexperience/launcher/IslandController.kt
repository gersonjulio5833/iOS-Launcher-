package com.iphoneexperience.launcher

import android.animation.ValueAnimator
import android.content.Context
import android.content.SharedPreferences
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Outline
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.ViewOutlineProvider
import android.view.WindowManager
import android.view.animation.DecelerateInterpolator
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.TextView

/**
 * "Dynamic Island": janela flutuante (permissão "Sobrepor a outras apps") com dados
 * REAIS da sessão multimédia activa. Sem sessão activa não mostra nada (a não ser que
 * o utilizador active a opção puramente visual "mostrar sem música").
 * Chamadas: NÃO implementado.
 */
object IslandController : MediaHub.Listener {
    private var ctx: Context? = null
    private var wm: WindowManager? = null
    private var view: IslandView? = null
    private var prefListener: SharedPreferences.OnSharedPreferenceChangeListener? = null

    fun start(c: Context) {
        ctx = c
        wm = c.getSystemService(WindowManager::class.java)
        MediaHub.listeners.add(this)
        val l = SharedPreferences.OnSharedPreferenceChangeListener { _, _ -> refresh() }
        prefListener = l
        Prefs.get(c).sp.registerOnSharedPreferenceChangeListener(l)
        refresh()
    }

    fun stop() {
        MediaHub.listeners.remove(this)
        prefListener?.let { ctx?.let { c -> Prefs.get(c).sp.unregisterOnSharedPreferenceChangeListener(it) } }
        remove()
    }

    override fun onMediaChanged() { refresh() }

    fun refresh() {
        val c = ctx ?: return
        val p = Prefs.get(c)
        val shouldShow = p.islandEnabled && Settings.canDrawOverlays(c) &&
            (MediaHub.hasSession() || p.islandAlways)
        if (!shouldShow) { remove(); return }
        if (view == null) add(c, p)
        view?.update()
        view?.let { v ->
            val lp = v.layoutParams as WindowManager.LayoutParams
            lp.y = c.dpi(p.islandOffsetDp)
            try { wm?.updateViewLayout(v, lp) } catch (e: Exception) { }
        }
    }

    private fun add(c: Context, p: Prefs) {
        val v = IslandView(c, wm!!)
        val lp = WindowManager.LayoutParams(
            c.dpi(IslandView.COMPACT_W), c.dpi(IslandView.COMPACT_H),
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
        lp.y = c.dpi(p.islandOffsetDp)
        try { wm?.addView(v, lp); view = v } catch (e: Exception) { view = null }
    }

    private fun remove() {
        view?.let { it.release(); try { wm?.removeView(it) } catch (e: Exception) { } }
        view = null
    }
}

class IslandView(private val c: Context, private val wm: WindowManager) : FrameLayout(c) {
    companion object {
        const val COMPACT_W = 128
        const val COMPACT_H = 36
        const val EXP_W = 352
        const val EXP_H = 168
    }

    private val handler = Handler(Looper.getMainLooper())
    private var expanded = false
    private var anim: ValueAnimator? = null
    private val bg = GradientDrawable().apply { setColor(Color.BLACK) }

    // Estado compacto
    private val smallCover = ImageView(c).apply { scaleType = ImageView.ScaleType.CENTER_CROP }
    private val smallEq = EqualizerView(c)
    private val compactGroup = FrameLayout(c)

    // Estado expandido (moldura fixa de EXP_W x EXP_H, centrada)
    private val inner = FrameLayout(c)
    private val cover = ImageView(c).apply { scaleType = ImageView.ScaleType.CENTER_CROP }
    private val title = TextView(c)
    private val artist = TextView(c)
    private val eq = EqualizerView(c)
    private val tCur = TextView(c)
    private val tRem = TextView(c)
    private val bar = ProgressBarView(c)
    private val btnPrev = ImageView(c)
    private val btnPlay = ImageView(c)
    private val btnNext = ImageView(c)

    private val ticker = object : Runnable {
        override fun run() {
            updateProgress()
            if (expanded && MediaHub.isPlaying()) handler.postDelayed(this, 500)
        }
    }
    private val autoCollapse = Runnable { setExpanded(false) }

    init {
        background = bg
        clipToOutline = true
        outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(v: View, o: Outline) { o.setRoundRect(0, 0, v.width, v.height, minOf(v.height / 2f, c.dp(40f))) }
        }
        // compacto
        compactGroup.addView(smallCover, FrameLayout.LayoutParams(c.dpi(24), c.dpi(24)).apply {
            gravity = Gravity.CENTER_VERTICAL or Gravity.START; marginStart = c.dpi(8) })
        smallCover.clipToOutline = true
        smallCover.outlineProvider = roundOutline(c.dpi(6).toFloat())
        compactGroup.addView(smallEq, FrameLayout.LayoutParams(c.dpi(22), c.dpi(18)).apply {
            gravity = Gravity.CENTER_VERTICAL or Gravity.END; marginEnd = c.dpi(12) })
        addView(compactGroup, FrameLayout.LayoutParams(MATCH, MATCH))

        // expandido
        val ew = c.dpi(EXP_W)
        val eh = c.dpi(EXP_H)
        cover.clipToOutline = true
        cover.outlineProvider = roundOutline(c.dpi(12).toFloat())
        inner.addView(cover, FrameLayout.LayoutParams(c.dpi(56), c.dpi(56)).apply { leftMargin = c.dpi(20); topMargin = c.dpi(20) })
        title.apply { setTextColor(Color.WHITE); textSize = 17f; setTypeface(typeface, android.graphics.Typeface.BOLD); maxLines = 1; ellipsize = android.text.TextUtils.TruncateAt.END }
        artist.apply { setTextColor(0xB3FFFFFF.toInt()); textSize = 15f; maxLines = 1; ellipsize = android.text.TextUtils.TruncateAt.END }
        inner.addView(title, FrameLayout.LayoutParams(c.dpi(210), WRAP).apply { leftMargin = c.dpi(88); topMargin = c.dpi(24) })
        inner.addView(artist, FrameLayout.LayoutParams(c.dpi(210), WRAP).apply { leftMargin = c.dpi(88); topMargin = c.dpi(46) })
        inner.addView(eq, FrameLayout.LayoutParams(c.dpi(26), c.dpi(22)).apply { leftMargin = ew - c.dpi(46); topMargin = c.dpi(26) })
        for (t in listOf(tCur, tRem)) { t.setTextColor(0x99FFFFFF.toInt()); t.textSize = 11f }
        inner.addView(tCur, FrameLayout.LayoutParams(c.dpi(40), WRAP).apply { leftMargin = c.dpi(20); topMargin = c.dpi(88) })
        inner.addView(bar, FrameLayout.LayoutParams(ew - c.dpi(120), c.dpi(6)).apply { leftMargin = c.dpi(60); topMargin = c.dpi(94) })
        tRem.gravity = Gravity.END
        inner.addView(tRem, FrameLayout.LayoutParams(c.dpi(44), WRAP).apply { leftMargin = ew - c.dpi(60); topMargin = c.dpi(88) })
        val sz = c.dpi(34)
        fun place(v: ImageView, res: Int, x: Int) {
            v.setImageResource(res); v.setColorFilter(Color.WHITE)
            inner.addView(v, FrameLayout.LayoutParams(sz, sz).apply { leftMargin = x - sz / 2; topMargin = eh - c.dpi(24) - sz })
        }
        place(btnPrev, R.drawable.ic_prev, ew / 2 - c.dpi(76))
        place(btnPlay, R.drawable.ic_pause, ew / 2)
        place(btnNext, R.drawable.ic_next, ew / 2 + c.dpi(76))
        btnPrev.setOnClickListener { MediaHub.previous(); keepOpen() }
        btnNext.setOnClickListener { MediaHub.next(); keepOpen() }
        btnPlay.setOnClickListener { MediaHub.playPause(); keepOpen() }
        cover.setOnClickListener { MediaHub.openApp(); setExpanded(false) }
        addView(inner, FrameLayout.LayoutParams(ew, eh, Gravity.CENTER))
        inner.alpha = 0f
        inner.visibility = View.GONE

        setOnClickListener { if (!expanded) setExpanded(true) else setExpanded(false) }
    }

    private fun roundOutline(r: Float) = object : ViewOutlineProvider() {
        override fun getOutline(v: View, o: Outline) { o.setRoundRect(0, 0, v.width, v.height, r) }
    }

    private fun keepOpen() {
        handler.removeCallbacks(autoCollapse)
        handler.postDelayed(autoCollapse, 6000)
    }

    fun update() {
        val art: Bitmap? = MediaHub.art()
        if (art != null) { smallCover.setImageBitmap(art); cover.setImageBitmap(art) }
        else { smallCover.setImageResource(R.drawable.ic_note); smallCover.setColorFilter(0xFFFA2D48.toInt()); cover.setImageResource(R.drawable.ic_note); cover.setColorFilter(0xFFFA2D48.toInt()) }
        if (art != null) { smallCover.clearColorFilter(); cover.clearColorFilter() }
        title.text = MediaHub.title() ?: ""
        artist.text = MediaHub.artist() ?: ""
        val playing = MediaHub.isPlaying()
        btnPlay.setImageResource(if (playing) R.drawable.ic_pause else R.drawable.ic_play)
        smallEq.setActive(playing); eq.setActive(playing)
        smallCover.visibility = if (MediaHub.hasSession()) View.VISIBLE else View.INVISIBLE
        smallEq.visibility = smallCover.visibility
        updateProgress()
        handler.removeCallbacks(ticker)
        if (expanded && playing) handler.post(ticker)
        if (!MediaHub.hasSession() && expanded) setExpanded(false)
    }

    private fun fmt(ms: Long): String {
        val s = (ms / 1000).coerceAtLeast(0)
        return (s / 60).toString() + ":" + (s % 60).toString().padStart(2, '0')
    }

    private fun updateProgress() {
        val d = MediaHub.duration()
        val pos = MediaHub.position()
        bar.fraction = if (d > 0) (pos.toFloat() / d).coerceIn(0f, 1f) else 0f
        tCur.text = fmt(pos)
        tRem.text = if (d > 0) "-" + fmt(d - pos) else ""
    }

    fun setExpanded(e: Boolean) {
        if (e == expanded || (e && !MediaHub.hasSession())) return
        expanded = e
        handler.removeCallbacks(autoCollapse)
        anim?.cancel()
        val lp = layoutParams as WindowManager.LayoutParams
        val w0 = lp.width; val h0 = lp.height
        val w1 = c.dpi(if (e) EXP_W else COMPACT_W)
        val h1 = c.dpi(if (e) EXP_H else COMPACT_H)
        if (e) { inner.visibility = View.VISIBLE }
        val dur = if (Prefs.get(c).animations) 320L else 0L
        anim = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = dur
            interpolator = DecelerateInterpolator(1.6f)
            addUpdateListener { a ->
                val t = a.animatedValue as Float
                lp.width = (w0 + (w1 - w0) * t).toInt()
                lp.height = (h0 + (h1 - h0) * t).toInt()
                try { wm.updateViewLayout(this@IslandView, lp) } catch (ex: Exception) { }
                val k = if (e) t else 1f - t
                inner.alpha = k
                compactGroup.alpha = 1f - k
                invalidateOutline()
            }
            addListener(object : android.animation.AnimatorListenerAdapter() {
                override fun onAnimationEnd(a: android.animation.Animator) { if (!e) inner.visibility = View.GONE }
            })
            start()
        }
        if (e) { keepOpen(); handler.post(ticker) }
    }

    fun release() { handler.removeCallbacksAndMessages(null); anim?.cancel(); smallEq.setActive(false); eq.setActive(false) }
}

/** Barras animadas (equalizador) usadas no estado compacto/expandido. */
class EqualizerView(c: Context) : View(c) {
    private val paint = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply { color = 0xFFFA5C7C.toInt() }
    private var active = false
    private var phase = 0f
    private val anim = ValueAnimator.ofFloat(0f, (Math.PI * 2).toFloat()).apply {
        duration = 900; repeatCount = ValueAnimator.INFINITE
        addUpdateListener { phase = it.animatedValue as Float; invalidate() }
    }
    fun setActive(a: Boolean) {
        active = a
        if (a && !anim.isStarted) anim.start() else if (!a) { anim.cancel(); invalidate() }
    }
    override fun onDetachedFromWindow() { anim.cancel(); super.onDetachedFromWindow() }
    override fun onDraw(cv: android.graphics.Canvas) {
        val n = 4
        val gap = width * 0.12f
        val bw = (width - gap * (n - 1)) / n
        for (i in 0 until n) {
            val f = if (active) 0.35f + 0.65f * Math.abs(Math.sin((phase + i * 0.9f).toDouble())).toFloat() else 0.3f
            val bh = height * f
            val x = i * (bw + gap)
            cv.drawRoundRect(x, (height - bh) / 2f, x + bw, (height + bh) / 2f, bw / 2f, bw / 2f, paint)
        }
    }
}

class ProgressBarView(c: Context) : View(c) {
    var fraction = 0f
        set(v) { field = v; invalidate() }
    private val track = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply { color = 0x40FFFFFF }
    private val fill = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE }
    override fun onDraw(cv: android.graphics.Canvas) {
        val r = height / 2f
        cv.drawRoundRect(0f, 0f, width.toFloat(), height.toFloat(), r, r, track)
        cv.drawRoundRect(0f, 0f, width * fraction, height.toFloat(), r, r, fill)
    }
}
