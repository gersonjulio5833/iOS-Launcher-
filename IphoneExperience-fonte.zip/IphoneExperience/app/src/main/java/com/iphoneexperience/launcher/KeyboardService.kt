package com.iphoneexperience.launcher

import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.inputmethodservice.InputMethodService
import android.os.Handler
import android.os.Looper
import android.util.TypedValue
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import android.view.inputmethod.EditorInfo
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView

/**
 * Teclado opcional inspirado no iOS (português). Funcional: letras, maiúsculas, números, símbolos,
 * acentos por pressão longa, espaço, apagar (com repetição), enter/pesquisar e sugestões simples
 * baseadas num pequeno dicionário local (não aprende e não envia nada para fora).
 */
class KeyboardService : InputMethodService() {
    private val ui = Handler(Looper.getMainLooper())
    private var dark = false
    private var mode = 0              // 0 letras, 1 números, 2 símbolos
    private var shift = 1             // 0 minúsculas, 1 uma vez, 2 bloqueado
    private var word = StringBuilder()
    private lateinit var root: LinearLayout
    private lateinit var sugg: LinearLayout
    private lateinit var rowsBox: LinearLayout

    private val letters = listOf("qwertyuiop", "asdfghjkl", "zxcvbnm")
    private val nums = listOf("1234567890", "-/:;()€&@\"", ".,?!'")
    private val syms = listOf("[]{}#%^*+=", "_\\|~<>$£¥•", ".,?!'")
    private val accents = mapOf(
        'a' to "áàâãä", 'e' to "éèêë", 'i' to "íìîï", 'o' to "óòôõö", 'u' to "úùûü",
        'c' to "ç", 'n' to "ñ"
    )
    private val dict = listOf(
        "olá", "obrigado", "obrigada", "bom", "boa", "dia", "tarde", "noite", "sim", "não", "como", "estás", "está",
        "tudo", "bem", "para", "porque", "quando", "onde", "quem", "que", "com", "sem", "mais", "menos", "muito",
        "pouco", "hoje", "amanhã", "ontem", "agora", "depois", "antes", "aqui", "ali", "ainda", "também", "mas",
        "por", "favor", "desculpa", "claro", "certo", "casa", "trabalho", "amigo", "amiga", "telemóvel", "mensagem",
        "chamada", "vamos", "vou", "estou", "podes", "posso", "preciso", "quero", "gosto", "tenho", "temos",
        "fazer", "ver", "falar", "saber", "ir", "vir", "ser", "estar", "ter", "dar", "tudo", "nada", "alguém"
    )

    override fun onCreateInputView(): View {
        dark = Prefs.get(this).isDark(this)
        root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(if (dark) 0xFF1B1B1D.toInt() else 0xFFD1D3D9.toInt())
        root.setPadding(dpi(3), dpi(2), dpi(3), dpi(6))
        sugg = LinearLayout(this)
        sugg.orientation = LinearLayout.HORIZONTAL
        sugg.gravity = Gravity.CENTER
        root.addView(sugg, LinearLayout.LayoutParams(MATCH, dpi(40)))
        rowsBox = LinearLayout(this)
        rowsBox.orientation = LinearLayout.VERTICAL
        root.addView(rowsBox, LinearLayout.LayoutParams(MATCH, WRAP))
        render()
        return root
    }

    override fun onStartInputView(info: EditorInfo?, restarting: Boolean) {
        super.onStartInputView(info, restarting)
        word.setLength(0)
        mode = 0
        val cap = currentInputConnection?.getCursorCapsMode(info?.inputType ?: 0) ?: 0
        shift = if (cap != 0) 1 else 0
        if (::root.isInitialized) { render() }
    }

    // ---------------------------------------------------------------- desenho

    private fun keyBg(special: Boolean, pressed: Boolean = false) = rounded(
        when {
            pressed -> if (dark) 0xFF5A5A5E.toInt() else 0xFFAEB3BE.toInt()
            special -> if (dark) 0xFF3A3A3C.toInt() else 0xFFABB1BB.toInt()
            else -> if (dark) 0xFF6A6A6C.toInt() else Color.WHITE
        }, dp(5f)
    )

    private fun key(label: String?, icon: Int?, weight: Float, special: Boolean, onTap: () -> Unit, onLong: (() -> Unit)? = null, repeat: Boolean = false): View {
        val f = FrameLayout(this)
        f.background = keyBg(special)
        val txtColor = if (dark) Color.WHITE else Color.BLACK
        if (icon != null) {
            val iv = ImageView(this); iv.setImageResource(icon); iv.setColorFilter(txtColor)
            f.addView(iv, FrameLayout.LayoutParams(dpi(22), dpi(22), Gravity.CENTER))
        } else {
            val t = TextView(this)
            t.text = label; t.setTextColor(txtColor)
            t.setTextSize(TypedValue.COMPLEX_UNIT_SP, if ((label?.length ?: 0) > 1) 15f else 22f)
            t.gravity = Gravity.CENTER
            f.addView(t, FrameLayout.LayoutParams(MATCH, MATCH))
        }
        var rep: Runnable? = null
        var longFired = false
        f.setOnTouchListener { v, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    v.background = keyBg(special, true)
                    v.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
                    longFired = false
                    if (repeat) {
                        onTap()
                        rep = object : Runnable { override fun run() { onTap(); ui.postDelayed(this, 55) } }
                        ui.postDelayed(rep!!, 400)
                    } else if (onLong != null) {
                        rep = Runnable { longFired = true; onLong() }
                        ui.postDelayed(rep!!, 380)
                    }
                }
                MotionEvent.ACTION_UP -> {
                    v.background = keyBg(special)
                    rep?.let { ui.removeCallbacks(it) }
                    if (!repeat && !longFired) onTap()
                }
                MotionEvent.ACTION_CANCEL -> { v.background = keyBg(special); rep?.let { ui.removeCallbacks(it) } }
            }
            true
        }
        f.layoutParams = LinearLayout.LayoutParams(0, MATCH, weight).apply { setMargins(dpi(3), dpi(4), dpi(3), dpi(4)) }
        return f
    }

    private fun row(vararg views: View): LinearLayout {
        val r = LinearLayout(this)
        r.orientation = LinearLayout.HORIZONTAL
        for (v in views) r.addView(v)
        r.layoutParams = LinearLayout.LayoutParams(MATCH, dpi(50))
        return r
    }

    private fun render() {
        rowsBox.removeAllViews()
        val src = when (mode) { 1 -> nums; 2 -> syms; else -> letters }
        for ((ri, chars) in src.withIndex()) {
            val views = mutableListOf<View>()
            if (ri == 2) {
                if (mode == 0) views.add(key(null, if (shift == 0) R.drawable.ic_shift else R.drawable.ic_shift, 1.5f, true, { cycleShift() }))
                else views.add(key(if (mode == 1) "#+=" else "123", null, 1.5f, true, { mode = if (mode == 1) 2 else 1; render() }))
            }
            for (ch in chars) views.add(charKey(ch))
            if (ri == 2) views.add(key(null, R.drawable.ic_backspace, 1.5f, true, { del() }, null, true))
            if (ri == 1 && mode == 0) { views.add(0, spacer(0.5f)); views.add(spacer(0.5f)) }
            rowsBox.addView(row(*views.toTypedArray()))
        }
        val bottom = row(
            key(if (mode == 0) "123" else "ABC", null, 1.3f, true, { mode = if (mode == 0) 1 else 0; render() }),
            key(null, R.drawable.ic_keyboard, 1.0f, true, { switchToNextInputMethod(false) }),
            key("espaço", null, 4.2f, false, { commit(" "); endWord() }),
            key(enterLabel(), null, 1.6f, true, { enter() })
        )
        rowsBox.addView(bottom)
        updateSuggestions()
    }

    private fun spacer(w: Float): View = View(this).apply { layoutParams = LinearLayout.LayoutParams(0, MATCH, w) }

    private fun charKey(ch: Char): View {
        val shown = if (mode == 0 && shift != 0) ch.uppercaseChar() else ch
        val alts = if (mode == 0) accents[ch] else null
        return key(shown.toString(), null, 1f, false, { typeChar(shown) }, if (alts != null) { { showAccents(alts, shown) } } else null)
    }

    private fun enterLabel(): String = when ((currentInputEditorInfo?.imeOptions ?: 0) and EditorInfo.IME_MASK_ACTION) {
        EditorInfo.IME_ACTION_SEARCH -> "pesquisar"
        EditorInfo.IME_ACTION_SEND -> "enviar"
        EditorInfo.IME_ACTION_GO -> "ir"
        EditorInfo.IME_ACTION_DONE -> "ok"
        EditorInfo.IME_ACTION_NEXT -> "seguinte"
        else -> "↵"
    }

    // ---------------------------------------------------------------- acções

    private fun commit(s: String) { currentInputConnection?.commitText(s, 1) }

    private fun typeChar(c: Char) {
        commit(c.toString())
        if (c.isLetter() || c == '\'' || c == '-') word.append(c) else endWord()
        if (mode == 0 && shift == 1) { shift = 0; render() } else updateSuggestions()
    }

    private fun endWord() { word.setLength(0); updateSuggestions() }

    private fun cycleShift() { shift = (shift + 1) % 3; render() }

    private fun del() {
        val ic = currentInputConnection ?: return
        val sel = ic.getSelectedText(0)
        if (!sel.isNullOrEmpty()) ic.commitText("", 1) else ic.deleteSurroundingText(1, 0)
        if (word.isNotEmpty()) word.setLength(word.length - 1)
        updateSuggestions()
    }

    private fun enter() {
        val ic = currentInputConnection ?: return
        val action = (currentInputEditorInfo?.imeOptions ?: 0) and EditorInfo.IME_MASK_ACTION
        val noEnter = ((currentInputEditorInfo?.imeOptions ?: 0) and EditorInfo.IME_FLAG_NO_ENTER_ACTION) != 0
        if (action != EditorInfo.IME_ACTION_NONE && action != EditorInfo.IME_ACTION_UNSPECIFIED && !noEnter) ic.performEditorAction(action)
        else commit("\n")
        endWord()
    }

    private fun showAccents(alts: String, base: Char) {
        sugg.removeAllViews()
        val all = base.toString() + alts
        for (c in all) {
            val s = if (mode == 0 && shift != 0) c.uppercaseChar() else c
            val t = TextView(this)
            t.text = s.toString()
            t.setTextColor(if (dark) Color.WHITE else Color.BLACK)
            t.setTextSize(TypedValue.COMPLEX_UNIT_SP, 24f)
            t.gravity = Gravity.CENTER
            t.setOnClickListener {
                typeChar(s)
            }
            sugg.addView(t, LinearLayout.LayoutParams(0, MATCH, 1f))
        }
    }

    private fun updateSuggestions() {
        if (!::sugg.isInitialized) return
        sugg.removeAllViews()
        val w = word.toString().lowercase()
        val list = if (w.isEmpty()) listOf("Olá", "Obrigado", "Bom dia")
        else {
            val m = dict.filter { it.startsWith(w) && it != w }.take(3).toMutableList()
            if (m.isEmpty() || !dict.contains(w)) m.add(0, word.toString())
            m.distinct().take(3)
        }
        for ((i, s) in list.withIndex()) {
            val t = TextView(this)
            t.text = s
            t.setTextColor(if (dark) Color.WHITE else Color.BLACK)
            t.setTextSize(TypedValue.COMPLEX_UNIT_SP, 17f)
            t.gravity = Gravity.CENTER
            t.maxLines = 1
            t.setOnClickListener {
                val ic = currentInputConnection ?: return@setOnClickListener
                if (word.isNotEmpty()) ic.deleteSurroundingText(word.length, 0)
                val out = if (shift != 0 && word.isEmpty()) s.replaceFirstChar { it.uppercaseChar() } else s
                ic.commitText("$out ", 1)
                word.setLength(0)
                if (shift == 1) { shift = 0; render() } else updateSuggestions()
            }
            sugg.addView(t, LinearLayout.LayoutParams(0, MATCH, 1f))
            if (i < list.size - 1) {
                val d = View(this); d.setBackgroundColor(if (dark) 0xFF3A3A3C.toInt() else 0xFFB5B8C0.toInt())
                sugg.addView(d, LinearLayout.LayoutParams(1, dpi(22)))
            }
        }
    }

}
