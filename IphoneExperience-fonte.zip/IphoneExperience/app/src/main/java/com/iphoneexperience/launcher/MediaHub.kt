package com.iphoneexperience.launcher

import android.content.ComponentName
import android.content.Context
import android.graphics.Bitmap
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.os.SystemClock

/**
 * Sessões multimédia REAIS do Android (MediaSessionManager).
 * Só funciona depois de o utilizador conceder "Acesso a notificações" ao launcher.
 */
object MediaHub {
    interface Listener { fun onMediaChanged() }

    val listeners = mutableSetOf<Listener>()
    var controller: MediaController? = null
        private set
    private var msm: MediaSessionManager? = null
    private var component: ComponentName? = null

    private val callback = object : MediaController.Callback() {
        override fun onPlaybackStateChanged(state: PlaybackState?) = fire()
        override fun onMetadataChanged(metadata: MediaMetadata?) = fire()
        override fun onSessionDestroyed() { pick(msm?.let { safeSessions(it) }) }
    }
    private val sessionsListener =
        MediaSessionManager.OnActiveSessionsChangedListener { list -> pick(list) }

    private fun safeSessions(m: MediaSessionManager): List<MediaController>? = try {
        m.getActiveSessions(component)
    } catch (e: SecurityException) { null }

    fun start(ctx: Context) {
        val m = ctx.getSystemService(MediaSessionManager::class.java)
        val cn = ComponentName(ctx, NotifListener::class.java)
        msm = m
        component = cn
        try {
            m.addOnActiveSessionsChangedListener(sessionsListener, cn)
            pick(safeSessions(m))
        } catch (e: SecurityException) {
            pick(null)
        }
    }

    fun stop() {
        try { msm?.removeOnActiveSessionsChangedListener(sessionsListener) } catch (e: Exception) { }
        pick(null)
    }

    private fun pick(list: List<MediaController>?) {
        val best = list?.firstOrNull { it.playbackState?.state == PlaybackState.STATE_PLAYING } ?: list?.firstOrNull()
        if (best?.sessionToken != controller?.sessionToken) {
            controller?.unregisterCallback(callback)
            controller = best
            controller?.registerCallback(callback)
        }
        fire()
    }

    private fun fire() { listeners.toList().forEach { it.onMediaChanged() } }

    fun hasSession(): Boolean = controller != null
    fun title(): String? = controller?.metadata?.getString(MediaMetadata.METADATA_KEY_TITLE)
    fun artist(): String? = controller?.metadata?.let {
        it.getString(MediaMetadata.METADATA_KEY_ARTIST) ?: it.getString(MediaMetadata.METADATA_KEY_ALBUM_ARTIST)
    }
    fun art(): Bitmap? = controller?.metadata?.let {
        it.getBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART) ?: it.getBitmap(MediaMetadata.METADATA_KEY_ART)
            ?: it.getBitmap(MediaMetadata.METADATA_KEY_DISPLAY_ICON)
    }
    fun isPlaying(): Boolean = controller?.playbackState?.state == PlaybackState.STATE_PLAYING
    fun duration(): Long = controller?.metadata?.getLong(MediaMetadata.METADATA_KEY_DURATION) ?: 0L
    fun position(): Long {
        val s = controller?.playbackState ?: return 0L
        if (s.state != PlaybackState.STATE_PLAYING) return s.position
        val elapsed = SystemClock.elapsedRealtime() - s.lastPositionUpdateTime
        return s.position + (elapsed * s.playbackSpeed).toLong()
    }

    fun playPause() {
        val c = controller ?: return
        if (isPlaying()) c.transportControls.pause() else c.transportControls.play()
    }
    fun next() { controller?.transportControls?.skipToNext() }
    fun previous() { controller?.transportControls?.skipToPrevious() }
    fun openApp() { try { controller?.sessionActivity?.send() } catch (e: Exception) { } }
}
