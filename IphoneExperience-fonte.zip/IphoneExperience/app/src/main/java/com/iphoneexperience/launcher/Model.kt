package com.iphoneexperience.launcher

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import org.json.JSONArray
import org.json.JSONObject

data class AppInfo(val id: String, val pkg: String, val cls: String, val label: String)

object AppRepo {
    /** Lista as apps realmente instaladas que têm ícone de lançamento. */
    fun loadAll(ctx: Context): List<AppInfo> {
        val pm = ctx.packageManager
        val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        return pm.queryIntentActivities(i, 0).map { r ->
            val ai = r.activityInfo
            AppInfo(ai.packageName + "/" + ai.name, ai.packageName, ai.name, r.loadLabel(pm).toString())
        }.sortedBy { it.label.lowercase() }
    }
}

sealed class Item {
    class App(val id: String) : Item()
    class Folder(var name: String, val ids: MutableList<String>) : Item()
}

class HomeModel {
    val pages: MutableList<MutableList<Item>> = mutableListOf()
    val dock: MutableList<String> = mutableListOf()

    fun normalize() {
        val flat = mutableListOf<Item>()
        for (page in pages) for (item in page) {
            when (item) {
                is Item.App -> flat.add(item)
                is Item.Folder -> when {
                    item.ids.size >= 2 -> flat.add(item)
                    item.ids.size == 1 -> flat.add(Item.App(item.ids[0]))
                }
            }
        }
        pages.clear()
        var i = 0
        while (i < flat.size) {
            pages.add(flat.subList(i, minOf(i + PAGE_SIZE, flat.size)).toMutableList())
            i += PAGE_SIZE
        }
        if (pages.isEmpty()) pages.add(mutableListOf())
    }

    private fun reconcile(apps: Map<String, AppInfo>, ctx: Context, firstRun: Boolean) {
        dock.retainAll { apps.containsKey(it) }
        for (page in pages) {
            val it = page.iterator()
            while (it.hasNext()) {
                when (val item = it.next()) {
                    is Item.App -> if (!apps.containsKey(item.id)) it.remove()
                    is Item.Folder -> item.ids.retainAll { id -> apps.containsKey(id) }
                }
            }
        }
        if (firstRun) dock.addAll(defaultDock(ctx, apps))
        val placed = HashSet<String>(dock)
        for (page in pages) for (item in page) {
            if (item is Item.App) placed.add(item.id) else if (item is Item.Folder) placed.addAll(item.ids)
        }
        if (pages.isEmpty()) pages.add(mutableListOf())
        for (app in apps.values.sortedBy { it.label.lowercase() }) {
            if (!placed.contains(app.id)) pages.last().add(Item.App(app.id))
        }
        normalize()
    }

    private fun defaultDock(ctx: Context, apps: Map<String, AppInfo>): List<String> {
        val pm = ctx.packageManager
        val intents = listOf(
            Intent(Intent.ACTION_DIAL),
            Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, Intent.CATEGORY_APP_BROWSER),
            Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, Intent.CATEGORY_APP_MESSAGING),
            Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, Intent.CATEGORY_APP_MUSIC),
            Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, Intent.CATEGORY_APP_GALLERY)
        )
        val out = mutableListOf<String>()
        for (i in intents) {
            if (out.size >= 4) break
            val pkg = try { pm.queryIntentActivities(i, PackageManager.MATCH_DEFAULT_ONLY).firstOrNull()?.activityInfo?.packageName } catch (e: Exception) { null }
            val app = apps.values.firstOrNull { it.pkg == pkg } ?: continue
            if (!out.contains(app.id)) out.add(app.id)
        }
        return out
    }

    fun save(prefs: Prefs) {
        val root = JSONObject()
        val pa = JSONArray()
        for (page in pages) {
            val arr = JSONArray()
            for (item in page) {
                val o = JSONObject()
                when (item) {
                    is Item.App -> { o.put("t", "a"); o.put("id", item.id) }
                    is Item.Folder -> { o.put("t", "f"); o.put("n", item.name); o.put("ids", JSONArray(item.ids)) }
                }
                arr.put(o)
            }
            pa.put(arr)
        }
        root.put("pages", pa)
        root.put("dock", JSONArray(dock))
        prefs.layoutJson = root.toString()
    }

    companion object {
        const val PAGE_SIZE = 24

        fun load(prefs: Prefs, apps: Map<String, AppInfo>, ctx: Context): HomeModel {
            val m = HomeModel()
            val raw = prefs.layoutJson
            var first = raw.isEmpty()
            if (!first) {
                try {
                    val root = JSONObject(raw)
                    val pa = root.getJSONArray("pages")
                    for (i in 0 until pa.length()) {
                        val arr = pa.getJSONArray(i)
                        val page = mutableListOf<Item>()
                        for (j in 0 until arr.length()) {
                            val o = arr.getJSONObject(j)
                            if (o.getString("t") == "a") page.add(Item.App(o.getString("id")))
                            else {
                                val ids = mutableListOf<String>()
                                val ja = o.getJSONArray("ids")
                                for (k in 0 until ja.length()) ids.add(ja.getString(k))
                                page.add(Item.Folder(o.getString("n"), ids))
                            }
                        }
                        m.pages.add(page)
                    }
                    val da = root.getJSONArray("dock")
                    for (i in 0 until da.length()) m.dock.add(da.getString(i))
                } catch (e: Exception) {
                    m.pages.clear(); m.dock.clear(); first = true
                }
            }
            m.reconcile(apps, ctx, first)
            m.save(prefs)
            return m
        }
    }
}
