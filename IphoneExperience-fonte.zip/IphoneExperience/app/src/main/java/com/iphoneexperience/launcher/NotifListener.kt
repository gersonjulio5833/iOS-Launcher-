package com.iphoneexperience.launcher

import android.os.Handler
import android.os.Looper
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

/**
 * Serviço de notificações: dá ao launcher (1) a lista real de notificações,
 * (2) acesso às sessões multimédia e (3) o "hospedeiro" da Dynamic Island.
 * Só funciona depois de o utilizador conceder acesso nas definições do Android.
 */
class NotifListener : NotificationListenerService() {
    companion object {
        var instance: NotifListener? = null
        val changeListeners = mutableSetOf<() -> Unit>()
        private val main = Handler(Looper.getMainLooper())

        fun snapshot(): List<StatusBarNotification> = try {
            instance?.activeNotifications?.toList() ?: emptyList()
        } catch (e: Exception) { emptyList() }

        fun notifyChange() { main.post { changeListeners.toList().forEach { it() } } }
    }

    override fun onListenerConnected() {
        instance = this
        MediaHub.start(this)
        IslandController.start(this)
        notifyChange()
    }

    override fun onListenerDisconnected() {
        instance = null
        MediaHub.stop()
        IslandController.stop()
        notifyChange()
    }

    override fun onNotificationPosted(sbn: StatusBarNotification?) { notifyChange() }
    override fun onNotificationRemoved(sbn: StatusBarNotification?) { notifyChange() }
}
