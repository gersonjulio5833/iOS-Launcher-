package com.iphoneexperience.launcher

import android.content.Context
import android.view.MotionEvent
import android.view.View
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.LinearLayout

/** Paginação horizontal com encaixe por página (sem dependências externas). */
class PagerView(ctx: Context) : HorizontalScrollView(ctx) {
    private val strip = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL }
    var current = 0
        private set
    var onPageChanged: ((Int) -> Unit)? = null
    private var flung = false
    val pageCount: Int get() = strip.childCount

    init {
        isHorizontalScrollBarEnabled = false
        overScrollMode = OVER_SCROLL_NEVER
        isFillViewport = true
        addView(strip, FrameLayout.LayoutParams(WRAP, MATCH))
    }

    fun setPages(pages: List<View>, keep: Boolean = true) {
        strip.removeAllViews()
        for (p in pages) strip.addView(p, LinearLayout.LayoutParams(maxOf(width, 1), MATCH))
        current = if (keep) current.coerceIn(0, maxOf(pages.size - 1, 0)) else 0
        post { scrollTo(current * width, 0) }
        onPageChanged?.invoke(current)
    }

    fun addPage(p: View) {
        strip.addView(p, LinearLayout.LayoutParams(maxOf(width, 1), MATCH))
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        super.onSizeChanged(w, h, ow, oh)
        for (i in 0 until strip.childCount) {
            val lp = strip.getChildAt(i).layoutParams
            lp.width = w
            strip.getChildAt(i).layoutParams = lp
        }
        scrollTo(current * w, 0)
    }

    fun snapTo(page: Int, animate: Boolean = true) {
        val target = page.coerceIn(0, maxOf(strip.childCount - 1, 0))
        val changed = target != current
        current = target
        if (animate) smoothScrollTo(target * width, 0) else scrollTo(target * width, 0)
        if (changed) onPageChanged?.invoke(current)
    }

    override fun fling(velocityX: Int) {
        flung = true
        val base = Math.round(scrollX / width.toFloat().coerceAtLeast(1f))
        val target = when {
            velocityX > 700 -> current + 1
            velocityX < -700 -> current - 1
            else -> base
        }
        snapTo(target)
    }

    override fun onTouchEvent(ev: MotionEvent): Boolean {
        if (ev.actionMasked == MotionEvent.ACTION_DOWN) flung = false
        val r = super.onTouchEvent(ev)
        if ((ev.actionMasked == MotionEvent.ACTION_UP || ev.actionMasked == MotionEvent.ACTION_CANCEL) && !flung) {
            snapTo(Math.round(scrollX / width.toFloat().coerceAtLeast(1f)))
        }
        return r
    }
}
