package com.iphoneexperience.launcher

import android.content.Context
import android.content.SharedPreferences
import android.content.res.Configuration
import kotlin.reflect.KProperty

class IntPref(private val sp: SharedPreferences, private val k: String, private val d: Int) {
    operator fun getValue(t: Any?, p: KProperty<*>): Int = sp.getInt(k, d)
    operator fun setValue(t: Any?, p: KProperty<*>, v: Int) { sp.edit().putInt(k, v).apply() }
}

class BoolPref(private val sp: SharedPreferences, private val k: String, private val d: Boolean) {
    operator fun getValue(t: Any?, p: KProperty<*>): Boolean = sp.getBoolean(k, d)
    operator fun setValue(t: Any?, p: KProperty<*>, v: Boolean) { sp.edit().putBoolean(k, v).apply() }
}

class StrPref(private val sp: SharedPreferences, private val k: String, private val d: String) {
    operator fun getValue(t: Any?, p: KProperty<*>): String = sp.getString(k, d) ?: d
    operator fun setValue(t: Any?, p: KProperty<*>, v: String) { sp.edit().putString(k, v).apply() }
}

/** Preferências do launcher, guardadas localmente (SharedPreferences). */
class Prefs private constructor(ctx: Context) {
    val sp: SharedPreferences = ctx.getSharedPreferences("ios_launcher", Context.MODE_PRIVATE)

    var userName by StrPref(sp, "name", "")
    var theme by IntPref(sp, "theme", 0)              // 0 auto, 1 claro, 2 escuro
    var iconScale by IntPref(sp, "icon_scale", 100)   // 80..120 %
    var glass by IntPref(sp, "glass", 60)             // 0..100
    var animations by BoolPref(sp, "animations", true)
    var showLabels by BoolPref(sp, "labels", true)
    var showSearch by BoolPref(sp, "search", true)
    var wallpaperMode by IntPref(sp, "wallpaper", 0)  // 0 estilo inicial, 1 azul, 2 imagem própria
    var islandEnabled by BoolPref(sp, "island", false)
    var islandAlways by BoolPref(sp, "island_always", false)
    var islandOffsetDp by IntPref(sp, "island_offset", 10)
    var layoutJson by StrPref(sp, "layout", "")

    fun isDark(ctx: Context): Boolean = when (theme) {
        1 -> false
        2 -> true
        else -> (ctx.resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) ==
            Configuration.UI_MODE_NIGHT_YES
    }

    companion object {
        @Volatile private var inst: Prefs? = null
        fun get(ctx: Context): Prefs =
            inst ?: synchronized(this) { inst ?: Prefs(ctx.applicationContext).also { inst = it } }
    }
}
