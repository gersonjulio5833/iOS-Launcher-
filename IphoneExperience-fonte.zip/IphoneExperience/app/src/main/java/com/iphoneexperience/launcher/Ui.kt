package com.iphoneexperience.launcher

import android.content.Context
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView

fun Context.dp(v: Float): Float = v * resources.displayMetrics.density
fun Context.dpi(v: Int): Int = (v * resources.displayMetrics.density + 0.5f).toInt()

const val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
const val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

fun rounded(color: Int, radius: Float): GradientDrawable =
    GradientDrawable().apply { setColor(color); cornerRadius = radius }

fun oval(color: Int): GradientDrawable =
    GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(color) }

fun glassLight(p: Prefs): Int =
    Color.argb((255 * (0.15f + 0.45f * p.glass / 100f)).toInt(), 255, 255, 255)

fun glassDark(p: Prefs): Int =
    Color.argb((255 * (0.35f + 0.5f * p.glass / 100f)).toInt(), 28, 28, 30)

fun Context.iconView(res: Int, tint: Int, sizePx: Int): ImageView =
    ImageView(this).apply {
        setImageResource(res)
        setColorFilter(tint)
        layoutParams = ViewGroup.LayoutParams(sizePx, sizePx)
    }

fun View.pressScale(enabled: Boolean) {
    if (!enabled) return
    setOnTouchListener { v, e ->
        when (e.actionMasked) {
            android.view.MotionEvent.ACTION_DOWN -> v.animate().scaleX(0.93f).scaleY(0.93f).setDuration(90).start()
            android.view.MotionEvent.ACTION_UP, android.view.MotionEvent.ACTION_CANCEL ->
                v.animate().scaleX(1f).scaleY(1f).setDuration(140).start()
        }
        false
    }
}
