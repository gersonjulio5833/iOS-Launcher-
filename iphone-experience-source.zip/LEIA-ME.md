# iPhone Experience — Launcher iOS 18 para Android

Launcher Android (sem root) com aparência inspirada no iOS 18, feito para o **ASUS Zenfone 8 Flip com Android 13**.

## 1. Arquitectura

| Camada | Tecnologia | Função |
|---|---|---|
| Launcher nativo | **Kotlin** (`android/`) | Actividade HOME, lista de apps e ícones originais, abrir apps, lanterna, volume, brilho, rotação, Não incomodar, sessões multimédia, notificações, estado das chamadas, painéis oficiais do Android |
| Interface visual | React + Tailwind (`src/`), mostrada num WebView local | Ecrã inicial, ecrã de bloqueio, Centro de Controlo, Dynamic Island, Ajustes, notificações |
| Teclado | **Kotlin** `InputMethodService` (`android/.../ime/`) | Teclado opcional estilo iOS com acentos portugueses e sugestões |

**Porquê este modelo híbrido?** Todas as integrações com o sistema usam APIs nativas em Kotlin. A interface é uma página local (sem Internet, a app nem tem a permissão `INTERNET`), carregada através do `WebViewAssetLoader`. Assim existe uma única fonte visual, que pode ser verificada no navegador e comparada com as referências, e que permite efeitos como o desfoque translúcido (`backdrop-filter`), difíceis de reproduzir com Views nativas no Android 13. A ponte JavaScript ↔ Kotlin está em `src/lib/native.ts` e em `Bridge.kt`.

```
android/
  app/src/main/AndroidManifest.xml      ← HOME + LAUNCHER, serviços, permissões
  app/src/main/java/com/iphoneexperience/launcher/
    MainActivity.kt   ← WebView, receptores de sistema, imersão, voltar/início
    Bridge.kt         ← métodos chamados pela UI (window.IOSBridge)
    SystemInfo.kt     ← estado (Wi-Fi, BT, bateria…) e painéis oficiais
    IconProvider.kt   ← ícones originais (adaptativos) em /icons/<id>.png
    MediaHub.kt       ← sessões multimédia reais (MediaSessionManager)
    NotifService.kt   ← NotificationListenerService
    ime/              ← teclado iOS (IosKeyboardService, KeyboardView, Words)
src/                  ← interface (React)
.github/workflows/build-apk.yml ← compilação na nuvem
```

## 2. Instalar o APK já compilado (o caminho mais simples)

Este projecto foi compilado e verificado no ambiente de desenvolvimento. Na página de pré-visualização, toca em **«Transferir APK»** (ficheiro `iPhoneExperience.apk`).

1. Abre o ficheiro transferido no Chrome ou na app Ficheiros.
2. Se o Android pedir, permite **«Instalar apps desconhecidas»** para o Chrome/Ficheiros.
3. Toca em **Instalar** e depois em **Abrir**.

## 3. Compilar na nuvem só com o telemóvel (GitHub Actions)

Precisas apenas de uma conta gratuita no GitHub. Usa o Chrome com **«Site para computador»** activado (menu ⋮).

### Opção A — GitHub Codespaces (recomendada; terminal na nuvem)
1. Transfere o código-fonte (`iphone-experience-source.zip`) a partir da página de pré-visualização.
2. Em github.com toca em **+ › New repository**, dá-lhe um nome (ex.: `iphone-experience`), marca **Add a README** e toca em **Create repository**.
3. No repositório toca em **Code › Codespaces › Create codespace on main**. Abre-se um editor na nuvem.
4. Arrasta o `.zip` para a lista de ficheiros do editor (ou usa o botão direito › *Upload*).
5. No terminal do Codespace (é na nuvem, não no teu telemóvel), cola:
   ```
   unzip -o iphone-experience-source.zip && rm iphone-experience-source.zip
   git add -A && git commit -m "Projecto iPhone Experience" && git push
   ```
6. Vai ao separador **Actions**: a tarefa **«Compilar APK»** começa sozinha (cerca de 5 a 8 minutos).
7. Quando terminar, abre **Releases** (página inicial do repositório, à direita) e toca em **iPhoneExperience.apk** para o transferir e instalar.

### Opção B — Carregar ficheiros pelo navegador
Em **Add file › Upload files**, envia todo o conteúdo do `.zip`, mantendo as pastas `android/`, `src/` e `.github/`. No telemóvel é difícil manter a estrutura de pastas, por isso a Opção A é mais fiável.

> Também podes compilar manualmente: **Actions › Compilar APK › Run workflow**.

## 4. Configuração depois de instalar

1. **Launcher predefinido**: prime o botão Início e escolhe **iPhone Experience › Sempre**. Em alternativa: *Ajustes › Definir como Launcher predefinido*.
2. **Ajustes › Permissões do Launcher**. Todas as permissões são opcionais e concedidas nos ecrãs oficiais do Android:
   - *Acesso às notificações*: notificações reais e música actual (Dynamic Island e Centro de Controlo).
   - *Acesso Não incomodar*: Foco e modo silencioso.
   - *Modificar definições do sistema*: brilho e bloqueio de rotação.
   - *Telefone*: indicador de chamada na Dynamic Island.
3. **Teclado (opcional)**: *Ajustes › Teclado › Activar «Teclado iOS»* e depois *Escolher teclado*.

## 5. Gestos

| Gesto | Acção |
|---|---|
| Deslizar para baixo a partir do canto superior direito | Centro de Controlo |
| Deslizar para baixo a partir do topo (lado esquerdo) | Centro de Notificações |
| Deslizar para baixo no meio do ecrã | Pesquisa |
| Deslizar para a esquerda ou direita | Páginas e Biblioteca de Apps (última página) |
| Toque prolongado num ícone | Menu: alterar ícone, informações da app, editar, remover |
| Toque prolongado e arrastar | Mover; largar sobre outra app cria uma pasta; levar à margem muda de página |
| Tocar ou manter premida a Dynamic Island | Expandir os controlos multimédia |
| ⏻ no Centro de Controlo | Ecrã de bloqueio complementar |
| Botão Início com o Launcher aberto | Fecha painéis e pastas e volta à página 1 |

## 6. Testar a interface no navegador
Para a pré-visualização: `npm install && npm run dev`. No navegador não existe acesso ao Android. Os conteúdos com a etiqueta **DEMO** são exemplos e podem ser desligados em *Ajustes › Perfil › Dados de demonstração*.
