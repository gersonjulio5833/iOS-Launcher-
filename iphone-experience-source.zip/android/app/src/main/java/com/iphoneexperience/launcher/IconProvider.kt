package com.iphoneexperience.launcher

import android.content.ComponentName
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.drawable.AdaptiveIconDrawable
import android.graphics.drawable.Drawable
import android.util.LruCache
import android.webkit.WebResourceResponse
import androidx.webkit.WebViewAssetLoader
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.net.URLDecoder

/**
 * Serve os ícones originais das apps em https://appassets.androidplatform.net/icons/<id>.png
 * Os ícones adaptativos são compostos (fundo + primeiro plano) num quadrado completo,
 * para que a UI aplique a máscara "squircle" do iOS.
 */
class IconProvider(private val ctx: Context) : WebViewAssetLoader.PathHandler {

    companion object {
        private const val SIZE = 192
        private val cache = object : LruCache<String, ByteArray>(6 * 1024 * 1024) {
            override fun sizeOf(key: String, value: ByteArray) = value.size
        }
        fun invalidate(pkg: String?) {
            if (pkg == null) { cache.evictAll(); return }
            cache.snapshot().keys.filter { it == pkg || it.startsWith("$pkg/") }.forEach { cache.remove(it) }
        }
    }

    override fun handle(path: String): WebResourceResponse? {
        val id = URLDecoder.decode(path.removeSuffix(".png"), "UTF-8")
        val bytes = cache.get(id) ?: render(id)?.also { cache.put(id, it) } ?: return null
        return WebResourceResponse("image/png", null, ByteArrayInputStream(bytes)).apply {
            responseHeaders = mapOf("Cache-Control" to "max-age=86400")
        }
    }

    private fun render(id: String): ByteArray? = try {
        val pm = ctx.packageManager
        val cn = if (id.contains('/')) ComponentName.unflattenFromString(id) else null
        val d: Drawable = if (cn != null) pm.getActivityIcon(cn) else pm.getApplicationIcon(id)
        val bmp = Bitmap.createBitmap(SIZE, SIZE, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        if (d is AdaptiveIconDrawable) {
            // As camadas têm 108dp com 72dp visíveis: ampliamos 1,5x e recortamos ao centro.
            val inset = SIZE / 4
            d.background?.let { it.setBounds(-inset, -inset, SIZE + inset, SIZE + inset); it.draw(c) }
            d.foreground?.let { it.setBounds(-inset, -inset, SIZE + inset, SIZE + inset); it.draw(c) }
        } else {
            // Ícone antigo: fundo branco como no iOS, com margem.
            c.drawColor(Color.WHITE)
            val pad = (SIZE * 0.12).toInt()
            d.setBounds(pad, pad, SIZE - pad, SIZE - pad)
            d.draw(c)
        }
        val out = ByteArrayOutputStream()
        bmp.compress(Bitmap.CompressFormat.PNG, 100, out)
        bmp.recycle()
        out.toByteArray()
    } catch (_: Exception) { null }
}
