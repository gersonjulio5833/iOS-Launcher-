package com.iphoneexperience.launcher

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.app.NotificationManager
import android.bluetooth.BluetoothAdapter
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.graphics.Color
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.net.wifi.WifiManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.telephony.PhoneStateListener
import android.telephony.TelephonyManager
import android.view.View
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.webkit.WebViewAssetLoader
import org.json.JSONObject

class MainActivity : Activity() {

    lateinit var webView: WebView
    private val main = Handler(Looper.getMainLooper())
    private var fileCallback: ValueCallback<Array<Uri>>? = null
    var hideStatusBar = true
    var torchOn = false
    var callState = "idle"
    var callSince = 0L
    private var phoneListener: PhoneStateListener? = null
    private var statusPending = false

    companion object {
        @Volatile var instance: MainActivity? = null
        private const val REQ_FILE = 41
        private const val REQ_PHONE = 42
        private const val REQ_ALL = 43
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        getPreferences(MODE_PRIVATE).let { p ->
            if (!p.getBoolean("perm_asked", false)) {
                p.edit().putBoolean("perm_asked", true).apply()
                main.postDelayed({ requestAllPermissions() }, 1500)
            }
        }
        instance = this
        WindowCompat.setDecorFitsSystemWindows(window, false)
        window.statusBarColor = Color.TRANSPARENT
        window.navigationBarColor = Color.TRANSPARENT

        val loader = WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .addPathHandler("/icons/", IconProvider(this))
            .build()

        webView = WebView(this).apply {
            setBackgroundColor(Color.BLACK)
            overScrollMode = View.OVER_SCROLL_NEVER
            isVerticalScrollBarEnabled = false
            isHorizontalScrollBarEnabled = false
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.allowFileAccess = false
            settings.allowContentAccess = false
            settings.mediaPlaybackRequiresUserGesture = true
            settings.textZoom = 100
            setLayerType(View.LAYER_TYPE_HARDWARE, null)
            addJavascriptInterface(Bridge(this@MainActivity), "IOSBridge")
            webViewClient = object : WebViewClient() {
                override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? =
                    loader.shouldInterceptRequest(request.url)
                override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                    val url = request.url
                    if (url.host == "appassets.androidplatform.net") return false
                    try { startActivity(Intent(Intent.ACTION_VIEW, url).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (_: Exception) {}
                    return true
                }
            }
            webChromeClient = object : WebChromeClient() {
                override fun onShowFileChooser(view: WebView, cb: ValueCallback<Array<Uri>>, params: FileChooserParams): Boolean {
                    fileCallback?.onReceiveValue(null)
                    fileCallback = cb
                    return try {
                        startActivityForResult(params.createIntent(), REQ_FILE); true
                    } catch (e: Exception) { fileCallback = null; false }
                }
            }
        }
        setContentView(webView)
        webView.loadUrl("https://appassets.androidplatform.net/assets/www/index.html")
        applyImmersive()
        registerReceivers()
        registerTorch()
        startPhoneListener()
    }

    // ---------- comunicação com a UI ----------
    fun emit(type: String, payload: String) {
        main.post {
            webView.evaluateJavascript(
                "window.__iosNative&&window.__iosNative.emit(${JSONObject.quote(type)},${JSONObject.quote(payload)})", null
            )
        }
    }

    /** Agrupa várias alterações de estado num único envio (poupa CPU/bateria). */
    fun emitStatus() {
        if (statusPending) return
        statusPending = true
        main.postDelayed({
            statusPending = false
            emit("status", SystemInfo.status(this).toString())
        }, 120)
    }

    fun applyImmersive() {
        main.post {
            val c = WindowInsetsControllerCompat(window, window.decorView)
            c.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            if (hideStatusBar) c.hide(WindowInsetsCompat.Type.statusBars()) else c.show(WindowInsetsCompat.Type.statusBars())
            c.isAppearanceLightStatusBars = false
            c.isAppearanceLightNavigationBars = false
        }
    }

    // ---------- receptores do sistema ----------
    private val packageReceiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            IconProvider.invalidate(i.data?.schemeSpecificPart)
            emit("apps", "{}")
        }
    }
    private val systemReceiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            when (i.action) {
                Intent.ACTION_SCREEN_ON -> emit("screen", JSONObject().put("on", true).put("secure", SystemInfo.deviceSecure(c)).toString())
                Intent.ACTION_SCREEN_OFF -> emit("screen", JSONObject().put("on", false).toString())
                Intent.ACTION_POWER_CONNECTED -> { emit("charging", "{}"); emitStatus() }
                else -> emitStatus()
            }
        }
    }

    private fun registerReceivers() {
        registerReceiver(packageReceiver, IntentFilter().apply {
            addAction(Intent.ACTION_PACKAGE_ADDED)
            addAction(Intent.ACTION_PACKAGE_REMOVED)
            addAction(Intent.ACTION_PACKAGE_CHANGED)
            addAction(Intent.ACTION_PACKAGE_REPLACED)
            addDataScheme("package")
        })
        registerReceiver(systemReceiver, IntentFilter().apply {
            addAction(Intent.ACTION_SCREEN_ON)
            addAction(Intent.ACTION_SCREEN_OFF)
            addAction(Intent.ACTION_BATTERY_CHANGED)
            addAction(Intent.ACTION_POWER_CONNECTED)
            addAction(Intent.ACTION_POWER_DISCONNECTED)
            addAction(Intent.ACTION_AIRPLANE_MODE_CHANGED)
            addAction(WifiManager.WIFI_STATE_CHANGED_ACTION)
            addAction(WifiManager.NETWORK_STATE_CHANGED_ACTION)
            addAction(BluetoothAdapter.ACTION_STATE_CHANGED)
            addAction(AudioManager.RINGER_MODE_CHANGED_ACTION)
            addAction(NotificationManager.ACTION_INTERRUPTION_FILTER_CHANGED)
            addAction("android.media.VOLUME_CHANGED_ACTION")
        })
    }

    private fun registerTorch() {
        try {
            val cm = getSystemService(Context.CAMERA_SERVICE) as CameraManager
            cm.registerTorchCallback(object : CameraManager.TorchCallback() {
                override fun onTorchModeChanged(cameraId: String, enabled: Boolean) {
                    torchOn = enabled; emitStatus()
                }
            }, main)
        } catch (_: Exception) {}
    }

    // ---------- chamadas (estado real; apenas com permissão) ----------
    @Suppress("DEPRECATION")
    fun startPhoneListener() {
        if (phoneListener != null) return
        if (checkSelfPermission(Manifest.permission.READ_PHONE_STATE) != PackageManager.PERMISSION_GRANTED) return
        val tm = getSystemService(Context.TELEPHONY_SERVICE) as TelephonyManager
        phoneListener = object : PhoneStateListener() {
            override fun onCallStateChanged(state: Int, phoneNumber: String?) {
                val s = when (state) {
                    TelephonyManager.CALL_STATE_RINGING -> "ringing"
                    TelephonyManager.CALL_STATE_OFFHOOK -> "offhook"
                    else -> "idle"
                }
                if (s != callState) {
                    callSince = if (s == "idle") 0 else System.currentTimeMillis()
                    callState = s
                    emit("call", callJson())
                }
            }
        }
        try { tm.listen(phoneListener, PhoneStateListener.LISTEN_CALL_STATE) } catch (_: Exception) { phoneListener = null }
    }

    fun callJson(): String = JSONObject().put("state", callState).put("since", callSince).toString()

    private val runtimePerms get() = buildList {
        add(Manifest.permission.READ_PHONE_STATE); add(Manifest.permission.READ_CONTACTS)
        if (android.os.Build.VERSION.SDK_INT >= 31) add(Manifest.permission.BLUETOOTH_CONNECT)
        if (android.os.Build.VERSION.SDK_INT >= 33) add(Manifest.permission.POST_NOTIFICATIONS)
    }.toTypedArray()

    /** Pede todas as permissões de execução de uma vez (primeiro arranque ou botão «Conceder tudo»). */
    fun requestAllPermissions() {
        val missing = runtimePerms.filter { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }
        if (missing.isNotEmpty()) main.post { requestPermissions(missing.toTypedArray(), REQ_ALL) }
    }

    fun requestOne(p: String) { main.post { requestPermissions(arrayOf(p), REQ_ALL) } }

    fun requestPhone() {
        main.post { requestPermissions(arrayOf(Manifest.permission.READ_PHONE_STATE), REQ_PHONE) }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQ_PHONE || requestCode == REQ_ALL) { startPhoneListener(); emitStatus() }
    }

    @Deprecated("API antiga ainda usada para o seletor de ficheiros")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        @Suppress("DEPRECATION")
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQ_FILE) {
            fileCallback?.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(resultCode, data))
            fileCallback = null
        }
    }

    // ---------- ciclo de vida ----------
    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        // Botão/gesto Início com o Launcher já em primeiro plano
        if (intent.hasCategory(Intent.CATEGORY_HOME)) emit("home", "{}")
    }

    @Deprecated("Mantido para compatibilidade com Android 13")
    override fun onBackPressed() {
        // Um Launcher nunca termina com o botão Voltar: a UI fecha pastas/painéis.
        emit("back", "{}")
    }

    override fun onResume() {
        super.onResume()
        applyImmersive()
        MediaHub.start(this)
        emit("resume", "{}")
        emitStatus()
        NotifService.instance?.let { emit("notifications", it.listJson().toString()) }
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        emitStatus()
    }

    override fun onDestroy() {
        try { unregisterReceiver(packageReceiver) } catch (_: Exception) {}
        try { unregisterReceiver(systemReceiver) } catch (_: Exception) {}
        @Suppress("DEPRECATION")
        phoneListener?.let { (getSystemService(Context.TELEPHONY_SERVICE) as TelephonyManager).listen(it, PhoneStateListener.LISTEN_NONE) }
        if (instance === this) instance = null
        webView.destroy()
        super.onDestroy()
    }

    fun isAtLeast(api: Int) = Build.VERSION.SDK_INT >= api
}
