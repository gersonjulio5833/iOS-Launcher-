package com.iphoneexperience.launcher

import android.content.ComponentName
import android.content.Context
import android.graphics.Bitmap
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.os.Handler
import android.os.Looper
import android.util.Base64
import org.json.JSONObject
import java.io.ByteArrayOutputStream

/**
 * Lê a sessão multimédia activa REAL (Spotify, YouTube Music, etc.) através do
 * MediaSessionManager. Requer o acesso às notificações concedido pelo utilizador.
 * Sem acesso, não devolve nada (a UI não mostra dados fictícios).
 */
object MediaHub {
    private var msm: MediaSessionManager? = null
    private var controller: MediaController? = null
    private var appCtx: Context? = null
    private var lastArtKey: String? = null
    private var lastArt: String? = null
    private val main = Handler(Looper.getMainLooper())

    private val sessionsListener = MediaSessionManager.OnActiveSessionsChangedListener { list -> pick(list) }

    private val cb = object : MediaController.Callback() {
        override fun onMetadataChanged(metadata: MediaMetadata?) = push()
        override fun onPlaybackStateChanged(state: PlaybackState?) = push()
        override fun onSessionDestroyed() { controller = null; push() }
    }

    fun start(ctx: Context) {
        val c = ctx.applicationContext
        appCtx = c
        if (!SystemInfo.notifAccess(c)) return
        try {
            val m = msm ?: (c.getSystemService(Context.MEDIA_SESSION_SERVICE) as MediaSessionManager).also { msm = it }
            val comp = ComponentName(c, NotifService::class.java)
            m.removeOnActiveSessionsChangedListener(sessionsListener)
            m.addOnActiveSessionsChangedListener(sessionsListener, comp, main)
            pick(m.getActiveSessions(comp))
        } catch (_: SecurityException) {
        } catch (_: Exception) {}
    }

    private fun pick(list: List<MediaController>?) {
        val best = list?.firstOrNull { it.playbackState?.state == PlaybackState.STATE_PLAYING }
            ?: list?.firstOrNull { it.metadata != null }
        if (best?.sessionToken != controller?.sessionToken) {
            controller?.unregisterCallback(cb)
            controller = best
            best?.registerCallback(cb, main)
        }
        push()
    }

    private fun push() {
        MainActivity.instance?.emit("media", json()?.toString() ?: "null")
    }

    fun json(): JSONObject? {
        val c = controller ?: return null
        val md = c.metadata ?: return null
        val title = md.getString(MediaMetadata.METADATA_KEY_TITLE) ?: md.getString(MediaMetadata.METADATA_KEY_DISPLAY_TITLE) ?: return null
        val st = c.playbackState
        val o = JSONObject()
            .put("title", title)
            .put("artist", md.getString(MediaMetadata.METADATA_KEY_ARTIST) ?: md.getString(MediaMetadata.METADATA_KEY_ALBUM_ARTIST) ?: "")
            .put("album", md.getString(MediaMetadata.METADATA_KEY_ALBUM) ?: "")
            .put("duration", md.getLong(MediaMetadata.METADATA_KEY_DURATION))
            .put("playing", st?.state == PlaybackState.STATE_PLAYING)
            .put("position", st?.position ?: 0L)
            .put("updatedAt", System.currentTimeMillis() - (if (st != null && st.lastPositionUpdateTime > 0) (android.os.SystemClock.elapsedRealtime() - st.lastPositionUpdateTime) else 0L))
            .put("pkg", c.packageName)
        try {
            val pm = appCtx?.packageManager
            if (pm != null) o.put("appLabel", pm.getApplicationLabel(pm.getApplicationInfo(c.packageName, 0)).toString())
        } catch (_: Exception) {}
        art(md, title)?.let { o.put("art", it) }
        return o
    }

    private fun art(md: MediaMetadata, title: String): String? {
        val key = title + "|" + md.getString(MediaMetadata.METADATA_KEY_ALBUM)
        if (key == lastArtKey) return lastArt
        val bmp: Bitmap = md.getBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART) ?: md.getBitmap(MediaMetadata.METADATA_KEY_ART) ?: md.getBitmap(MediaMetadata.METADATA_KEY_DISPLAY_ICON) ?: run {
            lastArtKey = key; lastArt = null; return null
        }
        val scaled = Bitmap.createScaledBitmap(bmp, 256, 256 * bmp.height / bmp.width.coerceAtLeast(1), true)
        val out = ByteArrayOutputStream()
        scaled.compress(Bitmap.CompressFormat.JPEG, 85, out)
        lastArtKey = key
        lastArt = "data:image/jpeg;base64," + Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP)
        return lastArt
    }

    fun action(a: String, value: Long) {
        val t = controller?.transportControls ?: return
        main.post {
            when (a) {
                "play" -> t.play()
                "pause" -> t.pause()
                "toggle" -> if (controller?.playbackState?.state == PlaybackState.STATE_PLAYING) t.pause() else t.play()
                "next" -> t.skipToNext()
                "prev" -> t.skipToPrevious()
                "seek" -> t.seekTo(value)
            }
        }
    }
}
