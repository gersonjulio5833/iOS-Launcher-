package com.iphoneexperience.launcher

import android.app.Notification
import android.app.PendingIntent
import android.os.Handler
import android.os.Looper
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import org.json.JSONArray
import org.json.JSONObject

/**
 * Serviço oficial de escuta de notificações (activado pelo utilizador nas definições do Android).
 * Usado para: lista de notificações, abrir a app de origem, dispensar e ler sessões multimédia.
 * Os dados não saem do dispositivo.
 */
class NotifService : NotificationListenerService() {

    companion object {
        @Volatile var instance: NotifService? = null
    }

    private val main = Handler(Looper.getMainLooper())
    private var pending = false

    override fun onListenerConnected() {
        instance = this
        MediaHub.start(this)
        push()
        MainActivity.instance?.emitStatus()
    }

    override fun onListenerDisconnected() {
        if (instance === this) instance = null
    }

    override fun onNotificationPosted(sbn: StatusBarNotification) = push()
    override fun onNotificationRemoved(sbn: StatusBarNotification) = push()

    private fun push() {
        if (pending) return
        pending = true
        main.postDelayed({
            pending = false
            MainActivity.instance?.emit("notifications", listJson().toString())
        }, 250)
    }

    fun listJson(): JSONArray {
        val arr = JSONArray()
        val list = try { activeNotifications ?: emptyArray() } catch (_: Exception) { emptyArray<StatusBarNotification>() }
        val pm = packageManager
        for (sbn in list) {
            val n = sbn.notification
            if (n.flags and Notification.FLAG_GROUP_SUMMARY != 0) continue
            if (n.category == Notification.CATEGORY_TRANSPORT) continue // multimédia já aparece na Dynamic Island
            val ex = n.extras
            val title = ex.getCharSequence(Notification.EXTRA_TITLE)?.toString() ?: ""
            val text = (ex.getCharSequence(Notification.EXTRA_BIG_TEXT) ?: ex.getCharSequence(Notification.EXTRA_TEXT))?.toString() ?: ""
            if (title.isBlank() && text.isBlank()) continue
            val label = try { pm.getApplicationLabel(pm.getApplicationInfo(sbn.packageName, 0)).toString() } catch (_: Exception) { sbn.packageName }
            arr.put(JSONObject()
                .put("key", sbn.key)
                .put("pkg", sbn.packageName)
                .put("appLabel", label)
                .put("title", title)
                .put("text", text)
                .put("time", sbn.postTime)
                .put("clearable", sbn.isClearable))
        }
        return arr
    }

    fun open(key: String) {
        val sbn = try { activeNotifications?.firstOrNull { it.key == key } } catch (_: Exception) { null } ?: return
        val pi: PendingIntent? = sbn.notification.contentIntent
        try {
            if (pi != null) pi.send() else packageManager.getLaunchIntentForPackage(sbn.packageName)?.let {
                it.addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK); startActivity(it)
            }
            if (sbn.notification.flags and Notification.FLAG_AUTO_CANCEL != 0) cancelNotification(key)
        } catch (_: Exception) {}
    }
}
