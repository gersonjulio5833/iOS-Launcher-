package com.iphoneexperience.launcher

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent

/** Serviço de acessibilidade mínimo: só executa acções globais pedidas pela UI. Não lê o conteúdo do ecrã. */
class OverlayService : AccessibilityService() {
    override fun onServiceConnected() { super.onServiceConnected(); instance = this }
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}
    override fun onUnbind(intent: android.content.Intent?): Boolean { instance = null; return super.onUnbind(intent) }

    companion object {
        @Volatile var instance: OverlayService? = null
        fun act(name: String): Boolean {
            val s = instance ?: return false
            val a = when (name) {
                "notifications" -> GLOBAL_ACTION_NOTIFICATIONS
                "quickSettings" -> GLOBAL_ACTION_QUICK_SETTINGS
                "recents" -> GLOBAL_ACTION_RECENTS
                "lock" -> if (android.os.Build.VERSION.SDK_INT >= 28) GLOBAL_ACTION_LOCK_SCREEN else return false
                else -> return false
            }
            return s.performGlobalAction(a)
        }
    }
}
