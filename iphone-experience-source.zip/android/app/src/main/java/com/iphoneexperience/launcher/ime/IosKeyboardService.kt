package com.iphoneexperience.launcher.ime

import android.content.res.Configuration
import android.inputmethodservice.InputMethodService
import android.os.Build
import android.view.View
import android.view.inputmethod.EditorInfo

/** Teclado opcional com aparência inspirada no iOS (método de introdução Android normal). */
class IosKeyboardService : InputMethodService() {

    private var kb: KeyboardView? = null

    override fun onCreateInputView(): View {
        val v = KeyboardView(this)
        v.service = this
        kb = v
        return v
    }

    override fun onStartInputView(info: EditorInfo, restarting: Boolean) {
        super.onStartInputView(info, restarting)
        kb?.apply {
            dark = (resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES
            editorInfo = info
            resetForField()
        }
    }

    override fun onUpdateSelection(oldSelStart: Int, oldSelEnd: Int, newSelStart: Int, newSelEnd: Int, candidatesStart: Int, candidatesEnd: Int) {
        super.onUpdateSelection(oldSelStart, oldSelEnd, newSelStart, newSelEnd, candidatesStart, candidatesEnd)
        kb?.refreshContext()
    }

    fun nextKeyboard() {
        if (Build.VERSION.SDK_INT >= 28) {
            if (!switchToNextInputMethod(false)) requestShowSelf(0)
        }
    }
}
