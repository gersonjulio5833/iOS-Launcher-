/* Vista Hoje: widgets, pesquisa de contactos e permissões. Abre com deslize desde a margem esquerda. */
(function () {
  var B = window.IOSBridge, el, timer;
  var G = 'background:rgba(255,255,255,.14);backdrop-filter:blur(20px) saturate(170%);-webkit-backdrop-filter:blur(20px) saturate(170%);border-radius:24px;padding:14px;color:#fff;';
  function st() { try { return JSON.parse(B.getStatus()); } catch (e) { return {}; } }
  function h(t, s, c) { var d = document.createElement(t); if (s) d.style.cssText = s; if (c) d.innerHTML = c; return d; }
  function close() { if (!el) return; el.style.transform = 'translateX(-100%)'; clearInterval(timer); var e = el; el = null; setTimeout(function () { e.remove(); }, 320); }
  function open() {
    if (el) return;
    el = h('div', 'position:fixed;inset:0;z-index:9999;overflow-y:auto;padding:max(env(safe-area-inset-top),44px) 16px 40px;background:rgba(10,12,24,.35);backdrop-filter:blur(28px) saturate(160%);-webkit-backdrop-filter:blur(28px) saturate(160%);transform:translateX(-100%);transition:transform .3s cubic-bezier(.2,.8,.2,1);font-family:-apple-system,Inter,system-ui,sans-serif;color:#fff;');
    el.className = 'inset-0'; /* o selector do vidro ignora camadas de ecrã inteiro */
    var head = h('div', 'display:flex;justify-content:space-between;align-items:center;margin-bottom:14px', '<b style="font-size:26px">Hoje</b>');
    var x = h('button', 'border:0;background:rgba(255,255,255,.2);color:#fff;border-radius:50%;width:32px;height:32px;font-size:16px', '✕'); x.onclick = close; head.appendChild(x); el.appendChild(head);
    var row = h('div', 'display:grid;grid-template-columns:1fr 1fr;gap:12px;margin-bottom:12px');
    var clock = h('div', G + 'min-height:130px;display:flex;flex-direction:column;justify-content:space-between'), cal = h('div', G + 'min-height:130px'), bat = h('div', G + 'margin-bottom:12px');
    row.append(clock, cal); el.append(row, bat);
    var sb = h('div', G + 'margin-bottom:12px'), inp = h('input', 'width:100%;box-sizing:border-box;border:0;outline:0;border-radius:12px;padding:10px 12px;background:rgba(255,255,255,.2);color:#fff;font-size:16px'), res = h('div', 'margin-top:8px');
    inp.placeholder = 'Pesquisar contactos'; sb.append(inp, res); el.appendChild(sb);
    var perm = h('div', G); el.appendChild(perm);
    function tick() {
      var d = new Date();
      clock.innerHTML = '<span style="font-size:12px;opacity:.8">' + d.toLocaleDateString('pt-PT', { weekday: 'long' }).toUpperCase() + '</span><b style="font-size:40px;font-weight:300">' + d.toLocaleTimeString('pt-PT', { hour: '2-digit', minute: '2-digit' }) + '</b><span style="font-size:12px;opacity:.8">' + d.toLocaleDateString('pt-PT', { day: 'numeric', month: 'long' }) + '</span>';
      var first = (new Date(d.getFullYear(), d.getMonth(), 1).getDay() + 6) % 7, n = new Date(d.getFullYear(), d.getMonth() + 1, 0).getDate(), g = '';
      for (var i = 0; i < first; i++) g += '<i></i>';
      for (var k = 1; k <= n; k++) g += '<span style="' + (k === d.getDate() ? 'background:#ff3b30;border-radius:50%;' : '') + '">' + k + '</span>';
      cal.innerHTML = '<div style="font-size:12px;font-weight:600;color:#ff453a;margin-bottom:4px">' + d.toLocaleDateString('pt-PT', { month: 'long' }).toUpperCase() + '</div><div style="display:grid;grid-template-columns:repeat(7,1fr);font-size:9px;text-align:center;line-height:14px">' + g + '</div>';
      var S = st();
      if (navigator.getBattery) navigator.getBattery().then(function (b) { bat.innerHTML = '<b>Bateria</b> &nbsp;' + Math.round(b.level * 100) + '%' + (b.charging ? ' ⚡' : '') + '<div style="height:8px;border-radius:4px;background:rgba(255,255,255,.25);margin-top:8px"><div style="height:8px;border-radius:4px;background:#34c759;width:' + Math.round(b.level * 100) + '%"></div></div>'; });
      var items = [['Contactos', 'contactsPerm', 'contacts'], ['Bluetooth', 'btPerm', 'bluetooth'], ['Notificações', 'postNotifPerm', 'notifications'], ['Sobrepor a outras apps', 'overlayPerm', 'overlay'], ['Acessibilidade (bloquear/painéis)', 'a11yEnabled', 'accessibility']];
      perm.innerHTML = '<b>Permissões</b>';
      if (!B) { perm.innerHTML += '<div style="opacity:.7;font-size:13px;margin-top:6px">Disponível no APK.</div>'; return; }
      items.forEach(function (it) {
        var ok = S[it[1]], r = h('div', 'display:flex;justify-content:space-between;align-items:center;margin-top:10px;font-size:14px', '<span>' + it[0] + '</span>');
        var b = h('button', 'border:0;border-radius:14px;padding:6px 12px;color:#fff;background:' + (ok ? '#34c759' : '#0a84ff'), ok ? 'Ativo' : 'Conceder');
        if (!ok) b.onclick = function () { B.requestPermission(it[2]); }; r.appendChild(b); perm.appendChild(r);
      });
      var all = h('button', 'width:100%;margin-top:12px;border:0;border-radius:14px;padding:10px;color:#fff;background:rgba(255,255,255,.22)', 'Conceder todas as permissões'); all.onclick = function () { B.requestPermission('all'); }; perm.appendChild(all);
    }
    inp.oninput = function () {
      res.innerHTML = '';
      var q = inp.value.trim(); if (!q || !B) return;
      if (!st().contactsPerm) { res.innerHTML = '<div style="font-size:13px;opacity:.8">Concede a permissão de Contactos abaixo.</div>'; return; }
      var list = []; try { list = JSON.parse(B.searchContacts(q)); } catch (e) {}
      list.forEach(function (c) { var r = h('div', 'display:flex;justify-content:space-between;padding:8px 2px;border-top:1px solid rgba(255,255,255,.15);font-size:15px', '<span>' + c.name.replace(/</g, '&lt;') + '</span><span style="opacity:.7">' + c.number + '</span>'); r.onclick = function () { B.dial(c.number); }; res.appendChild(r); });
    };
    tick(); document.body.appendChild(el); requestAnimationFrame(function () { el.style.transform = 'translateX(0)'; }); timer = setInterval(function () { if (document.activeElement !== inp) tick(); }, 2000);
    var sx; el.addEventListener('touchstart', function (e) { sx = e.touches[0].clientX; }, { passive: true }); el.addEventListener('touchend', function (e) { if (sx - e.changedTouches[0].clientX > 80) close(); }, { passive: true });
  }
  var down = null;
  addEventListener('pointerdown', function (e) { down = e.clientX < 22 ? { x: e.clientX, y: e.clientY } : null; }, true);
  addEventListener('pointermove', function (e) { if (down && e.clientX - down.x > 70 && Math.abs(e.clientY - down.y) < 60) { down = null; open(); } }, true);
  addEventListener('pointerup', function () { down = null; }, true);
  window.__abrirHoje = open;
})();
