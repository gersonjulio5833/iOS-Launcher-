import { useEffect, useLayoutEffect, useRef, useState } from "react";
import { useStore, useL } from "@/lib/store";
import { useRT, loadApps } from "@/lib/apps";
import * as N from "@/lib/native";
import { wallSrc } from "@/lib/wallpapers";
import HomeScreen from "@/components/HomeScreen";
import StatusBar from "@/components/StatusBar";
import DynamicIsland from "@/components/DynamicIsland";
import LockScreen from "@/components/LockScreen";
import ControlCenter from "@/components/ControlCenter";
import NotificationCenter from "@/components/NotificationCenter";
import Spotlight from "@/components/Spotlight";
import Settings from "@/components/Settings";

// Gancho para testes automatizados (sem efeito na utilização normal)
(window as any).__iosDebug = { rt: useRT, store: useStore };

function useViewport() {
  const [vp, setVp] = useState({ w: window.innerWidth, h: window.innerHeight });
  useEffect(() => {
    const on = () => setVp({ w: window.innerWidth, h: window.innerHeight });
    window.addEventListener("resize", on);
    return () => window.removeEventListener("resize", on);
  }, []);
  return vp;
}

const DEMO_ART = "data:image/svg+xml;utf8," + encodeURIComponent(`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100"><defs><linearGradient id="g" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#7b5cff"/><stop offset=".55" stop-color="#ff6fb5"/><stop offset="1" stop-color="#ffb36b"/></linearGradient></defs><rect width="100" height="100" fill="url(#g)"/><circle cx="50" cy="50" r="22" fill="none" stroke="#fff" stroke-opacity=".7" stroke-width="3"/><circle cx="50" cy="50" r="5" fill="#fff"/><text x="50" y="92" font-size="10" text-anchor="middle" fill="#fff" font-family="sans-serif" font-weight="700">DEMO</text></svg>`);

export default function App() {
  const L = useL();
  const vp = useViewport();
  const settings = useStore((s) => s.settings);
  const rt = useRT();
  const [homeKey, setHomeKey] = useState(0);
  const [systemDark, setSystemDark] = useState(() => window.matchMedia?.("(prefers-color-scheme: dark)").matches ?? false);
  const settingsRef = useRef(settings);
  settingsRef.current = settings;

  // Moldura de pré-visualização em ecrãs grandes (desktop)
  const framed = !N.isNative && vp.w > 600;
  const W = framed ? 393 : vp.w;
  const H = framed ? Math.min(852, vp.h - 60) : vp.h;
  const top = Math.round(54 * Math.min(1.12, W / 393));

  const dark = settings.theme === "dark" || (settings.theme === "auto" && (N.isNative ? rt.status.night : systemDark));

  // ---------- arranque ----------
  useLayoutEffect(() => {
    loadApps();
    const refresh = () => useRT.getState().set({ status: N.getStatus() });
    refresh();
    N.initWebBattery(refresh);
    if (N.isNative) {
      useRT.getState().set({ media: N.getMedia(), notifications: N.getNotifications(), call: N.getCall() });
    }
    const offs = [
      N.onNative("apps", () => loadApps()),
      N.onNative("status", (p) => useRT.getState().set({ status: { ...useRT.getState().status, ...(p || N.getStatus()) } })),
      N.onNative("media", (p) => useRT.getState().set({ media: p && p.title !== undefined ? p : null })),
      N.onNative("notifications", (p) => useRT.getState().set({ notifications: Array.isArray(p) ? p : [] })),
      N.onNative("call", (p) => useRT.getState().set({ call: p })),
      N.onNative("home", () => useRT.getState().set({ overlay: "none" })),
      N.onNative("resume", refresh),
      N.onNative("screen", (p: { on: boolean; secure: boolean }) => {
        const mode = settingsRef.current.lockEnabled;
        if (p?.on && (mode === "always" || (mode === "auto" && !p.secure))) useRT.getState().set({ locked: true, overlay: "none" });
      }),
      N.onNative("charging", refresh),
    ];
    const mq = window.matchMedia?.("(prefers-color-scheme: dark)");
    const onMq = (e: MediaQueryListEvent) => setSystemDark(e.matches);
    mq?.addEventListener?.("change", onMq);
    window.addEventListener("online", refresh);
    window.addEventListener("offline", refresh);
    N.nativeReady();
    return () => { offs.forEach((o) => o()); mq?.removeEventListener?.("change", onMq); };
  }, []);

  useEffect(() => { N.setImmersive(settings.hideAndroidStatusBar); }, [settings.hideAndroidStatusBar]);

  // Actualiza o estado ao abrir o Centro de Controlo / Ajustes
  useEffect(() => {
    if (rt.overlay === "cc" || rt.overlay === "settings") rt.set({ status: { ...N.getStatus(), torch: useRT.getState().status.torch } });
  }, [rt.overlay]); // eslint-disable-line

  // ---------- dados de demonstração (claramente marcados) ----------
  useEffect(() => {
    const st = useRT.getState();
    if (settings.demo) {
      if (!st.media || st.media.demo) st.set({ media: { title: L("Música de exemplo", "Sample Song"), artist: L("Artista de demonstração", "Demo Artist"), art: DEMO_ART, playing: true, position: 67000, duration: 221000, updatedAt: Date.now(), demo: true, appLabel: "Demo" } });
      if (!st.notifications.length) st.set({ notifications: [
        { key: "d1", pkg: "demo:messages", appLabel: L("Mensagens", "Messages"), title: "Ana", text: L("Chegaste bem? 😊 (exemplo)", "Did you get home ok? 😊 (sample)"), time: Date.now() - 120000, clearable: true, demo: true },
        { key: "d2", pkg: "demo:messages", appLabel: L("Mensagens", "Messages"), title: "Rui", text: L("Jantar às 20h? (exemplo)", "Dinner at 8? (sample)"), time: Date.now() - 900000, clearable: true, demo: true },
        { key: "d3", pkg: "demo:calendar", appLabel: L("Calendário", "Calendar"), title: L("Reunião", "Meeting"), text: L("Daqui a 15 minutos (exemplo)", "In 15 minutes (sample)"), time: Date.now() - 3600000, clearable: true, demo: true },
      ] });
    } else {
      if (st.media?.demo) st.set({ media: N.getMedia() });
      st.set({ notifications: st.notifications.filter((n) => !n.demo) });
    }
  }, [settings.demo]); // eslint-disable-line

  useEffect(() => N.onNative("webMediaAction", ({ action, value }: { action: string; value: number }) => {
    const m = useRT.getState().media;
    if (!m?.demo) return;
    const pos = m.playing ? m.position + (Date.now() - m.updatedAt) : m.position;
    let next = { ...m, position: pos, updatedAt: Date.now() };
    if (action === "toggle" || action === "play" || action === "pause") next.playing = action === "toggle" ? !m.playing : action === "play";
    if (action === "next" || action === "prev") next.position = 0;
    if (action === "seek") next.position = value;
    useRT.getState().set({ media: next });
  }), []);

  const unlock = () => { rt.set({ locked: false }); setHomeKey((k) => k + 1); };
  const closeOverlay = () => rt.set({ overlay: "none" });
  const fg = rt.overlay === "settings" ? (dark ? "#fff" : "#000") : "#fff";

  const screen = (
    <div className="relative overflow-hidden bg-black select-none" style={{ width: W, height: H, borderRadius: framed ? 52 : 0 }}>
      <div key={homeKey} className={"absolute inset-0 " + (homeKey ? "ios-home-in" : "")}>
        <img src={wallSrc(settings.wallpaper, dark)} alt="" className="absolute inset-0 w-full h-full object-cover" draggable={false} />
        <HomeScreen W={W} H={H} top={top} dark={dark} />
      </div>
      {rt.overlay === "spotlight" && <Spotlight dark={dark} onClose={closeOverlay} />}
      {rt.overlay === "cc" && <ControlCenter W={W} H={H} dark={dark} onClose={closeOverlay} />}
      {rt.overlay === "nc" && <NotificationCenter W={W} dark={dark} onClose={closeOverlay} />}
      {rt.overlay === "settings" && <Settings dark={dark} onClose={closeOverlay} />}
      {rt.locked && <LockScreen W={W} H={H} dark={dark} onUnlocked={unlock} />}
      <StatusBar W={W} color={fg} hideTime={rt.locked} />
      <DynamicIsland W={W} locked={rt.locked} />
      {rt.toast && (
        <div className="absolute left-1/2 z-[60] px-4 py-2.5 rounded-2xl text-white text-[14px] text-center ios-toast pointer-events-none"
          style={{ bottom: 120, width: "max-content", maxWidth: W - 48, background: "rgba(30,30,32,.82)", backdropFilter: "blur(20px)" }}>{rt.toast}</div>
      )}
    </div>
  );

  if (!framed) return screen;

  return (
    <div className="w-full h-full flex items-center justify-center gap-10" style={{ background: "radial-gradient(circle at 30% 20%, #2a2f3a, #0b0c10 70%)" }}>
      <div className="relative p-[12px] rounded-[64px]" style={{ background: "linear-gradient(145deg,#8a8d93,#3b3d42 40%,#9a9ca1 60%,#3a3b3f)", boxShadow: "0 30px 80px rgba(0,0,0,.6), inset 0 0 0 2px rgba(255,255,255,.15)" }}>
        <div className="rounded-[54px] p-[2px] bg-black">{screen}</div>
      </div>
      <div className="hidden lg:block max-w-[340px] text-white/80 text-[14px] leading-relaxed">
        <h1 className="text-white text-[26px] font-bold mb-2">iPhone Experience</h1>
        <p className="mb-3">{L("Pré-visualização interactiva do Launcher Android. Esta é a mesma interface que corre dentro do APK, onde fica ligada às apps e APIs reais do Android.", "Interactive preview of the Android launcher. This is the same UI that runs inside the APK, where it's wired to real Android apps and APIs.")}</p>
        <ul className="space-y-1.5 text-white/70">
          <li>• {L("Deslizar do canto superior direito → Centro de Controlo", "Swipe from top-right → Control Center")}</li>
          <li>• {L("Deslizar do topo esquerdo → Notificações", "Swipe from top-left → Notifications")}</li>
          <li>• {L("Deslizar para baixo no ecrã → Pesquisa", "Swipe down on Home → Search")}</li>
          <li>• {L("Toque prolongado num ícone → menu, editar, arrastar, pastas", "Long-press an icon → menu, edit, drag, folders")}</li>
          <li>• {L("Tocar na Dynamic Island → expandir", "Tap the Dynamic Island → expand")}</li>
          <li>• {L("Ajustes → Ecrã de bloqueio → Pré-visualizar", "Settings → Lock Screen → Preview")}</li>
        </ul>
        <div className="flex gap-2 mt-5">
          <a href="./iPhoneExperience.apk" download className="px-4 py-2.5 rounded-full bg-[#0A84FF] text-white font-semibold text-[14px]">{L("Transferir APK", "Download APK")}</a>
          <a href="./iphone-experience-source.zip" download className="px-4 py-2.5 rounded-full bg-white/15 text-white font-semibold text-[14px]">{L("Código-fonte", "Source code")}</a>
        </div>
        <p className="mt-4 text-white/50 text-[12px]">{L("Conteúdos com a etiqueta DEMO são exemplos, não dados reais.", "Content tagged DEMO are samples, not real data.")}</p>
      </div>
    </div>
  );
}
