import { memo, useState } from "react";
import { useRT, type AppEntry } from "@/lib/apps";
import { useStore, type Folder } from "@/lib/store";
import { isNative, iconUrl } from "@/lib/native";
import { IosIcon, LetterIcon, hasIosIcon } from "./IosIcons";

export function resolveIconKey(app: AppEntry, custom: Record<string, string>, iosIcons: boolean): string | null {
  const c = custom[app.id];
  if (c === "original") return null;
  if (c && hasIosIcon(c)) return c;
  if (app.internal) return "settings";
  if (app.demo) return app.iosKey ?? null;
  if (iosIcons && app.iosKey) return app.iosKey;
  return null;
}

export const IconImage = memo(function IconImage({ app, size }: { app: AppEntry; size: number }) {
  const custom = useStore((s) => s.settings.customIcons);
  const iosIcons = useStore((s) => s.settings.iosIcons);
  const lang = useStore((s) => s.settings.lang);
  const [err, setErr] = useState(false);
  const key = resolveIconKey(app, custom, iosIcons);
  return (
    <div className="ios-squircle relative overflow-hidden" style={{ width: size, height: size }}>
      {key ? (
        <IosIcon name={key} lang={lang} />
      ) : isNative && !err ? (
        <img src={iconUrl(app.id)} alt="" draggable={false} onError={() => setErr(true)} className="w-full h-full object-cover" />
      ) : (
        <LetterIcon label={app.label} />
      )}
      <div className="absolute inset-0 ios-squircle pointer-events-none" style={{ boxShadow: "inset 0 0 0 0.5px rgba(0,0,0,0.08)" }} />
    </div>
  );
});

export function FolderIcon({ folder, size, dark }: { folder: Folder; size: number; dark?: boolean }) {
  const apps = useRT((s) => s.apps);
  const mini = Math.round(size * 0.24);
  const gap = Math.round(size * 0.07);
  return (
    <div
      className="ios-squircle overflow-hidden grid content-start"
      style={{
        width: size, height: size, padding: Math.round(size * 0.11), gap,
        gridTemplateColumns: `repeat(3, ${mini}px)`,
        background: dark ? "rgba(60,60,67,0.45)" : "rgba(255,255,255,0.32)",
        backdropFilter: "blur(20px) saturate(160%)", WebkitBackdropFilter: "blur(20px) saturate(160%)",
      }}
    >
      {folder.apps.slice(0, 9).map((id) => apps[id] && (
        <div key={id} style={{ borderRadius: mini * 0.24, overflow: "hidden", width: mini, height: mini }}>
          <IconImage app={apps[id]} size={mini} />
        </div>
      ))}
    </div>
  );
}
