import { useEffect, useState } from "react";
import { useRT } from "@/lib/apps";
import { Battery, Cellular, Wifi, Airplane, Moon } from "./Glyphs";

export function useClock() {
  const [now, setNow] = useState(new Date());
  useEffect(() => {
    let t: any;
    const tick = () => {
      setNow(new Date());
      t = setTimeout(tick, 60000 - (Date.now() % 60000) + 20);
    };
    t = setTimeout(tick, 60000 - (Date.now() % 60000) + 20);
    return () => clearTimeout(t);
  }, []);
  return now;
}

export function fmtTime(d: Date) {
  return `${d.getHours()}:${String(d.getMinutes()).padStart(2, "0")}`;
}

export default function StatusBar({ W, color = "#fff", hideTime }: { W: number; color?: string; hideTime?: boolean }) {
  const now = useClock();
  const st = useRT((s) => s.status);
  const scale = Math.min(1.12, W / 393);
  return (
    <div className="absolute top-0 left-0 right-0 flex items-center justify-between pointer-events-none z-[47]"
      style={{ height: 54 * scale, padding: `${4 * scale}px ${30 * scale}px 0`, color }}>
      <div className="font-semibold tracking-tight" style={{ fontSize: 16.5 * scale, width: W * 0.28, textAlign: "center", opacity: hideTime ? 0 : 1 }}>{fmtTime(now)}</div>
      <div className="flex items-center gap-[6px]" style={{ width: W * 0.28, justifyContent: "center" }}>
        {st.dnd && <Moon size={13 * scale} />}
        {st.airplane ? <Airplane size={16 * scale} /> : <Cellular size={17 * scale} style={{ opacity: 1 }} className={st.signal ? "" : "opacity-40"} />}
        {st.wifiConnected && !st.airplane && <Wifi size={17 * scale} />}
        <Battery size={27 * scale} level={st.battery} charging={st.charging} />
      </div>
    </div>
  );
}
