import home from "@/assets/wall-home.jpg";
import lock from "@/assets/wall-lock.jpg";
import purple from "@/assets/wall-purple.jpg";
import dark from "@/assets/wall-dark.jpg";

export const WALLPAPERS: { key: string; src: string; pt: string; en: string }[] = [
  { key: "home", src: home, pt: "Onda Rosa", en: "Pink Wave" },
  { key: "lock", src: lock, pt: "Onda Azul", en: "Blue Wave" },
  { key: "purple", src: purple, pt: "Roxo Profundo", en: "Deep Purple" },
  { key: "dark", src: dark, pt: "Noite", en: "Night" },
];

export function wallSrc(key: string, darkMode = false) {
  if (key.startsWith("data:") || key.startsWith("blob:")) return key;
  if (key === "home" && darkMode) return dark;
  return WALLPAPERS.find((w) => w.key === key)?.src ?? home;
}
